---
name: ontheway-claude-motion-clip
description: >
  Create narrated short-form video ads for Facebook, Instagram, TikTok, and YouTube Shorts from
  product context, source media, or a script, rendered with HyperFrames. Use for requests such as
  "ทำวิดีโอแอด", "สร้างคลิปโฆษณา", "video ad", "ad video", "vertical ad", or turning footage,
  audio, or a sales page into a narrated promotional clip. Handles first-run setup, product intake,
  source analysis, concept selection, storyboard approval, voiceover, motion design, rendering, and
  customer-approved audio mixing. Not for simple captioning, unnarrated motion-graphics hits, or
  unrelated long-form editing.
---

# OntheWay's Claude MOTION Clip
*(skill id: `ontheway-claude-motion-clip`) — narrated short-form ad composer*

> **Handing the edit off to CapCut?** Read `/capcut-draft` first. CapCut cannot import
> XML / FCPXML / EDL — the only route is writing its draft folder. Two rules decide
> success: media must live under `~/Movies` (CapCut is sandboxed and cannot read
> `~/Downloads`), and the draft must be registered in `root_meta_info.json` while
> CapCut is quit.

The opinionated ad layer on top of **HyperFrames**. The HyperFrames skills own the engine
(composition contract, CLI, GSAP runtime, TTS/transcribe/bgm); this skill owns the **house
style, the up-front questions, the reusable animation vocabulary, the signature techniques,
and the production discipline** that produce a good ad.

Read the engine skills as needed: `hyperframes` (authoring + workflow), `hyperframes-cli`
(init/lint/inspect/preview/render), `hyperframes-media` (tts/transcribe), `hyperframes-animation`
(GSAP runtime + transitions). This skill does **not** restate the composition contract — it
assumes it.

## What this skill makes

A vertical/square/landscape narrated ad, usually **30–65s**: a voiceover drives the timeline,
the screen carries big synced type, real product assets (course cover, in-class slides, mascot,
instructor), and restrained motion. Two house art directions ship as presets; new ones can be
proposed per job.

---

## STEP −1 — FIRST-RUN ONBOARDING (verify setup before the FIRST video)

This skill is packaged and sold, so on a user's **first run** you must confirm the toolchain is ready —
**before** intake/producing — and **walk them through anything missing**. The two prerequisites:
**(1) HyperFrames** render engine (needs Node ≥ 22 + FFmpeg) and **(2) a Google Gemini API key** (it powers
both the **AI voiceover/TTS** and the **AI images**). **Assume the user has never set up an API key** —
guide them patiently with exact URLs/commands.

- **One-shot gate:** run the bundled **`scripts/setup.sh`** — it self-checks Node/FFmpeg/Python/Pillow,
  `npx hyperframes`, the **bundled** voiceover helper, and the **Gemini key** (via a real TTS test), and it
  **self-heals** a missing `vendor/gemini-tts/` from the global copy. Exit 0 = ready → go to STEP 0.
- **If `setup.sh` flags the Gemini key (TTS test failed)** → the user has **not connected Google yet**. Stop
  and **onboard them**: walk through getting a free key at **https://aistudio.google.com/apikey** (sign in →
  *Create API key* → copy the displayed key; current keys commonly start with `AQ…`) and save it to
  `~/.claude/secrets/gemini.env`. API-key prefixes may change, so never require or reject a key based on
  its prefix; validate it with the real TTS test instead. One key powers
  voiceover **and** images. **Don't proceed until the TTS test passes.**
- **If it flags Node/FFmpeg/deps** → guide the per-OS install (commands in `references/onboarding.md`).
- **Voiceover helper is bundled & portable** — call `scripts/setup.sh --tts` to get the resolved `tts.sh`
  path (prefers `vendor/gemini-tts/`, falls back to the global skill). Don't hardcode the global path.
- **Cutouts need no rembg by default** — use the bundled `scripts/cutout.py` (PIL flood-fill). Install rembg
  only for hard photoreal cutouts (`scripts/setup.sh --install-rembg`).

Do this **once**. Afterwards, only re-check if a later command fails with a missing-key / missing-dep error.
**Full step-by-step (beginner-proof) in `references/onboarding.md`; full dep list in `references/dependencies.md`.**

**Model self-healing:** all AI model IDs live in **`references/models.md`**. If any model call fails
(`model not found` / `deprecated` / locked-TTS errors), follow that file's protocol — **research the current
id (live API list + web), rewrite the row there, and retry** — so the skill repairs its own model drift.

---

## STEP 0 — Product-context intake (ALWAYS ask first)

Before anything else, run a **product-context intake**. Use `AskUserQuestion` (offer concrete
options; the user can always pick "Other"). Do not start composing until the **required** block is
answered. For the **optional** block: ask it up front too, but if the user doesn't answer, **decide
it for them and proceed — never block on optional**. Tell them which optional choices you made.

### Required — must have before building
1. **Brand** — ชื่อแบรนด์ (exact spelling; this governs every on-screen mention — see Hard rules).
2. **Product** — ชื่อสินค้า + **คุณสมบัติ/จุดเด่น** (what it is, what it does, the core selling points).
3. **Target profile** — กลุ่มเป้าหมายเป็นใคร (who we're talking to).
4. **Communication direction** — แนวทางการสื่อสาร: **โทนการพูด + สไตล์การสื่อสาร** (e.g. จริงจัง/สนุก/พรีเมียม,
   เล่าเรื่อง vs ขายตรง, formal vs เพื่อนคุยกัน).
5. **Voiceover gender** — เสียงพากย์ **ผู้ชาย / ผู้หญิง** (map to a TTS voice — see `gemini-tts` skill).

### Optional — ask, but auto-decide if unanswered (don't block)
- **Art direction** — offer the preset menu below; if no pick, choose the best fit for the
  brand/tone yourself and say which.
- **Voice detail** — โทนเสียงละเอียด (พลัง/นิ่ง/อบอุ่น, จังหวะเร็ว-ช้า) beyond just gender; default to a
  tone that matches the communication direction.
- **Source media** — ภาพ/วิดีโอสินค้าที่ผู้ใช้มี — **"ยิ่งเยอะยิ่งดี" (เอาที่มีเยอะที่สุด)**. This feeds STEP 1.
  If they have none, you'll source/generate assets yourself.

**Think in three axes: `Technical Direction × Visual Style × Palette`.** The *mechanic* (how the ad is
composed, animated, and cut) is separate from the *look* (scrapbook / serif / neon / photo) and the *colour*.
Pick a **technical direction** first (the reusable skeleton — see `references/technical-directions.md`, e.g.
**TD1 Centered-KV + drifting copy**, **TD2 full-bleed hard-cut**, **TD3 viewfinder + wipes**), then skin it
with a style + palette. The same TD carries many looks — don't treat a new *style* as if it were a new
*direction*. The templates/presets below are concrete `TD × style` instances.

**First: offer any fitting full template.** Before the à-la-carte palette menu, check `references/templates.md`
— if a saved **video template** matches the tone (e.g. **T1 Sitcom Pop** for playful/food/mass), show its
`poster.png` / `scene-flow.png` and offer it as a one-pick option (complete structure + KV method + audio).
Then the palette menu below for a fresh direction:

**Art-direction menu** (see `references/style-presets.md`):
- **Editorial White** — paper background, ink + wine + gold, magazine-clean, notebook texture.
- **Dark Bold / Secret Reveal** — near-black, gold = "the real thing", red = myth/risk, punchy.
- **Dark Red / Oxblood** — deep oxblood-red, gold + ember accents; warm-dramatic, framework/urgency angles.
- **Scrapbook Warm (Preset D)** — light cream + notebook grid, cut-paper-collage Gemini KVs (rembg) every
  1–3 slides + gentle float, real photos as taped polaroids, boil stickers. Cozy/hand-made; great for series diversity.
- **Cinematic Photoreal (Preset E)** — full-bleed photoreal AI plates + Ken Burns, central scrim, faint
  video-texture overlay, premium SVG elements. Serious/high-stakes; moody and premium.
- **Bold Risograph (Preset F)** — cream + halftone-red + misregistered poster frame, riso KVs, big condensed
  type, "stamp" + offset shadows. Loud/alarming; for risk/fraud/leak angles + short punchy scripts.
- **Propose a custom direction** — derive a fresh palette/type system from the brand's own look
  (recommended when it has a strong identity). Presets are starting points, not a cage.

Also pin down **format/proportion + length**: vertical **1080×1920** (default for ads), square
**1080×1080**, or landscape **1920×1080**; duration = the narration length (measure with `ffprobe`).

---

## STEP 1 — Collect & analyze the user's source material → `assets.json`

Once the intake is answered, **before scripting/building**, gather and *understand* what the user
already has so you can reuse their real footage/photos as backgrounds and key visuals.

1. **Tell the user to dump EVERYTHING into one folder.** You pick and announce the path — default
   **`<project>/source_material/`**. Anything goes: text/copy, images, product video, b-roll, logos,
   screenshots. ("โยนมารวมกันในโฟลเดอร์เดียวพอครับ — ผมจัดให้.")
2. **Analyze every file and write `source_material/assets.json`** — a catalog you consult later when
   placing backgrounds/KVs (don't guess from filenames). Per file record:
   - `file`, `type` (text/image/video), `description` (what it actually shows), `useFor`
     (hero / key-visual / background / logo / b-roll / quote), and `dims` or `duration`.
   - **For VIDEO, break it into time ranges** — an array of `{start, end, shot}` segments describing
     what's on screen / the event in each span (e.g. `{"start":"0:00","end":"0:04","shot":"มือชงกาแฟ close-up, ไอควัน"}`).
     This is what lets you pull a *specific range* as a background clip or freeze a frame as a KV.
   See `references/workflow.md` §"Analyze source material" for the how (ffprobe, scene cuts, vision captioning).
3. Use this catalog throughout the build — prefer the user's real media (correct ranges) over stock.

---

## STEP 2 — Concept options → user picks ONE (required gate)

Before any storyboard or script, **generate concept options and let the user choose**. Do not pick a
concept yourself and run with it — this is a hard gate.

- **Generate 2–3 DISTINCT concept directions** (different hook/angle/emotional driver — not the same
  idea reworded). Customer-facing copy → write them with **Gemini 3.6** (per the global copywriting
  rule), feeding it the intake facts + house style. Each concept = a short card, NOT a full script yet:
  - **ชื่อคอนเซปต์** + **angle หลัก** (ทำไมคนจะหยุดดู / อารมณ์ที่ใช้)
  - **hook line** (ประโยค/ภาพเปิด 3 วิแรก)
  - **โทน + art-direction ที่เข้ากับมัน** (1 บรรทัด)
- **Present them for selection** — prefer an interactive HTML picker (radio, default-select #1, plus an
  editable "แก้เอง" field and a copy button), matching the user's simple-HTML convention; `open` it.
- **Wait for the pick.** Only after the user chooses (or edits) ONE concept do you write the full
  scene-by-scene VO script for that concept, then proceed to the storyboard. The full script is written
  for the **chosen concept only** — don't script all of them.

---

## STEP 3 — Storyboard mockup (HTML) — get sign-off BEFORE building

After the **chosen concept's** script/timing exists but **before** authoring `index.html`, produce a **rough storyboard**
as a standalone HTML file and open it for the user to approve/iterate.

- **One file, one row per scene. Two columns:**
  - **Left = a ROUGH SVG sketch** of the frame — boxes/shapes/labels drawn with plain SVG primitives
    (rects, circles, text, lines) showing roughly where the KV/photo/headline/sticker sit. **Rough on
    purpose** — this is a thumbnail, not the real frame. Do NOT polish it.
  - **Right = AI's explanation** of the scene: the narration line it carries, what's shown, which
    asset/KV/background (reference `assets.json` ranges), and **WHY this scene exists** (its job in the ad).
- **SFX options per scene (customer picks by ear).** The storyboard is also the customer-facing sound
  approval. For each scene that wants a sound effect (slam, ka-ching, whoosh on transition, sparkle,
  pop…), embed **2–3 candidate SFX as `<audio controls>` previews** + a **"ไม่ใช้" (none)** option so the
  customer chooses by ear — never pick SFX blind for the final mix (you can't hear them). Offer a few
  **BGM track options** too. **BGM volume is FIXED at 20% — do NOT expose volume as a choice.** Sourcing +
  ffmpeg mixing recipe in `references/audio.md`.
- Keep it plain (white bg, black text, **`font-family: sans-serif`** — the browser default is Serif). Open it
  for the user with the **OS-correct opener** (macOS `open` / Windows `start ""` / Linux `xdg-open` — see house style).
- Iterate on the storyboard until the user signs off, *then* move to the build pipeline. The storyboard
  is the cheap place to fix structure — never skip straight to `index.html` for a fresh ad.

---

## Pipeline (once STEP 3 storyboard is approved)

1. **Transcribe the voiceover** to get a timing map → build the scene-by-scene plan synced to it.
   See `references/workflow.md` (Thai uses `whisper-cli` with `large-v3`, never the English default).
   **Do not treat the transcript/TTS text as final display copy.** A pronunciation-first TTS script may
   spell brands, acronyms, years, dates, quantities, and prices in Thai so the voice sounds correct; the
   subtitle layer must normalize them back to canonical display forms before composition.

   **Mandatory dual-text contract:** keep `tts_script` (audio pronunciation) separate from
   `display_subtitles` (customer-facing reading). Build a normalization dictionary from the intake,
   source page, and user brief, then apply it cue-by-cue without changing timing or meaning. Examples:
   `โมโนโกะ` → `Monoko`; `ออนเดอะเวย์ อะคาเดมี` → `OntheWay Academy`;
   `โรแอส` → `ROAS`; `ครีเอทีฟ เมทริกซ์ เฟรมเวิร์ก` → `Creative Matrix Framework`;
   `สองพันยี่สิบหก` → `2026`; `ร้อยชิ้น` → `100 ชิ้น`; spelled prices → `฿1,990`;
   `เจ็ดวัน` → `7 วัน`. Preserve natural Thai for ordinary words—do not force English everywhere.

   **Subtitle hard gate before render:** audit the SRT plus every embedded/burned subtitle node; grep for
   known phonetic aliases; verify exact brand casing/spacing, product/framework names, acronyms, Arabic
   numerals, dates, and currency; then send the final SRT/contact frames to a fresh third-party AI with a
   phonetic-leakage faults-only prompt. Any TTS-only spelling left on screen is a hard failure.
2. **Gather real assets — do this EARLY, grab generously.** Download the sale page's real images
   into the project's `resource_images/` up front: **course cover, instructor photo, guarantee/badge,
   logo, testimonial shots, in-class slides — everything useful**, not just one. They add authenticity
   AND frequently reveal ground-truth facts the page text got wrong (correct instructor name/spelling,
   brand palette, real tagline) — pulling them early catches errors before you script/voice. **Even when
   the art direction is AI-generated plates, still pull the real course cover** (hero at the reveal/CTA)
   **and instructor portrait** (avatar). Sale-page images usually sit under a predictable path
   (e.g. `/images/...`): extract every `/images/*.{webp,jpg,png}` (and `_next/image?url=…`, `og:image`,
   `background:url(…)`) from the HTML and download them all, then resize. Stock footage only as a faint
   background layer, never the hero. See `references/workflow.md`.
3. **Optionally generate an AI key visual** for the opener — 4 styles, background-removed, floating
   on the first frame. See `references/key-visual.md`. Offer it when a strong hook image would help.
4. **Build `index.html`** in the chosen art direction using the animation vocabulary
   (`references/animation.md`) and signature techniques (`references/techniques.md`).
5. **Validate**: `lint` → `validate` (WCAG) → `inspect` (overflow/overlap). Cross-scene overlap
   and hidden-element contrast warnings are usually false positives — confirm with rendered frames.
   Run a render-blocking orphan-line audit across every headline, prompt, label, and subtitle in the
   snapshot/contact sheet (see Hard rules). A one-word-or-one-syllable final line is a hard failure.
6. **Render, then VERIFY by extracting frames** with ffmpeg and actually looking at them before
   delivering. Never ship a render you haven't seen.
   - **Third-party orphan gate:** send representative rendered frames (≤5 per reviewer) to every fresh
     third-party AI vendor available and explicitly ask it to find one-word/one-syllable final wrapped
     lines. Any reported orphan returns the build to step 5, then re-render and re-review. Reviewers must
     identify the exact frame/text; the working agent's own visual check is not a substitute.
   - **⏱️ 3-minute paranoid watch — self-monitor every long render / ffmpeg mix; never hand the user a
     blind wait.** A render or audio mix should finish in a predictable time. Run it with progress
     output (`ffmpeg -progress <file> -nostats`, or the renderer's own progress) and **poll it on a
     timer (~every 1–3 min)**: report `% = done/total` + speed/ETA, and **self-abort the moment it looks
     wrong** — e.g. encoding past the known clip duration, 0% for minutes, or output size not growing.
     Overrunning the source length is almost always the infinite `-loop`/overlay bug (a still image added
     as `-loop 1 -i img.png` never EOFs, so `overlay` repeats forever) → **always cap output with
     `-t <source_duration>` + `-shortest`**. A 30-second "this looks stuck" beats a 3-hour silent hang
     that ends in "it was broken the whole time." (Same gotcha + reference watchdog: `hyperframes` skill →
     "Rendering / ffmpeg gotchas".)
7. **Prepare sound candidates — BGM + SFX + 3 VO versions.** Before mixing, gather the candidates:
   - **BGM:** Download 3–5 BGM tracks from a free library (Mixkit genre pages) that match the ad's
     tone. BGM volume is **fixed at 20%** — not a customer choice.
   - **SFX:** For each beat in the timeline, pick 2–3 candidate SFX. **Prefer the bundled Thai-familiar
     pack in `assets/soundfxs/`** (CapCut/TikTok-style stings, filenames carry their duration). Place
     each on its beat, **spread across the whole timeline (~1 per scene, ≥3–4s apart — never clustered),
     balance levels** (normalize so loud meme stings don't blast and faint ones don't vanish; fade-out
     any trim), and **keep total SFX ≤ 30% of the video's duration**.
   - **3 VO versions:** Generate the same script in **3 distinct voices** that fit the brief (e.g. 3
     female timbres; or mix male/female). Include the voice you already built with as one of the three.

8. **⛔ STEP 7-GATE — SOUND PICKER: customer picks BGM + SFX + voice (REQUIRED HARD GATE)**

   **THIS IS A MANDATORY STOP. DO NOT SKIP THIS STEP. DO NOT SELF-SELECT AND PROCEED.**

   Build a **playable `sound_picker.html`** with `<audio controls>` for:
   - Every **BGM candidate** (radio select, + "ไม่ใส่ BGM")
   - Every **per-beat SFX candidate** (radio per beat, + "ไม่ใส่" per beat)
   - The **3 voiceover versions** (radio select)

   `open` it for the customer. **WAIT for the customer's pick. Do NOT proceed to the mix until the
   customer has responded.** You cannot hear audio — you MUST let the customer choose by ear.
   If they pick a different voice than the build used, **re-render with it** before mixing.
   Full catalog + ffmpeg recipe in `references/audio.md`.

9. **Mix audio** — combine the customer's chosen BGM + SFX + VO onto the rendered mp4 with ffmpeg.
   Keep as `out_audio.mp4` until approved — never overwrite the clean `out.mp4`.
10. **Snapshot good versions** before iterating (`_versions/`), so a re-render never overrides a
    version the user asked to keep.

---

## House style — the taste this skill encodes

Keep these in mind for every decision; they are the difference between "fine" and "what the user likes":

- **Text-led, raw, confident ("ดิบ • text นำ • เท่ๆ").** Type is the design. Big sizeable fonts.
- **NO eyebrows / no tiny overline labels.** Every text element must be a real size. This is a hard ban.
- **Real assets > generic stock.** Use the product's own cover, slides, mascot, instructor.
  Generic stock footage is allowed ONLY as a faint moving background (opacity ~10–20%), never foreground.
- **Rotate the background often — NEVER one long clip.** Within a single ad, tile **2–4 different**
  stock clips and crossfade at the seams; **no single background clip should span more than ~2 scenes.**
  One clip running under the whole video reads as dead/static — keep the footage changing. (techniques.md #2.)
- **Series diversity — make each ad in a set look DIFFERENT.** When producing multiple ads for ONE
  product, push each video's **palette as far apart as the brand allows** — a distinct dominant color per
  video (e.g. teal, navy, oxblood, emerald, plum, editorial-cream across a 6-ad set). A brand often has
  only 3–4 colors, so some reuse is fine once you've exhausted the spread — but always *shift the
  treatment* so two ads never feel like the same template. **Backgrounds too: every ad uses a different
  SET of stock clips** — never reuse the same Pexels clip (or the same query) across two videos of the set.
- **Script / tone diversity across a set (user wants this by DEFAULT).** Just as the visuals rotate, **rotate the
  SCRIPT approach** so no two ads in a set feel the same. Cycle through distinct copy modes and alternate continuously
  — e.g. number/stat-led cold-open · emotional/story · short-punchy (~25–30s) vs full (~40s) · fact/checklist-led ·
  myth-bust · question-hook. Vary the **opening device** and the **emotional driver** per ad; avoid two consecutive
  ads sharing the same structure or hook type. When the user orders a batch, deliberately spread several tones across
  it rather than reusing one winning formula — diversity beats a single repeated template.
- **Subtle motion, not flashy.** "Keep it alive, don't make it busy." 1–2 ambient motions per scene
  (Ken Burns, gentle pulse, a background that drifts) on top of clean entrances.
- **Boil stickers are a DEFAULT, not a garnish (user loves them).** Sprinkle 2–3 cute hand-drawn SVG
  accents across the ad — paper clip, washi/scotch tape, star/sparkle, or a concept icon (a coin for
  "currency", a padlock for "prisoner") — that **boil**: a 2–3-frame stop-motion swap of near-identical
  path variants (`.fa`/`.fb`, `steps(1)` yoyo, finite repeats, ≤15% of frame, `data-layout-ignore`).
  They give the "arty, hand-made, cartoon" feel the user explicitly asked for. Put them on **every job**
  unless the brief is explicitly austere. (See techniques.md #4 for the mechanism.)
- **Sync type to speech** — follow the narration closely (not every word; ~+30% density beyond the
  bare minimum). The audio is the spine.
- **Precision matters.** When the user gives a number (opacity 12%, "≤15% of the clip", "no positional
  movement"), honor it exactly.
- **Show files with the OS-correct opener (don't assume Mac).** To display any generated file to the user
  (HTML picker / storyboard, or the rendered `.mp4`), launch it with the command for **their** OS — detect
  via `uname -s` / the platform, then: **macOS → `open "<path>"` · Windows → `start "" "<path>"` · Linux →
  `xdg-open "<path>"`**. The webview's clickable links frequently don't open, so always fire the opener
  explicitly after producing a file. Use absolute paths.

## Remarketing scripts — never announce "you already saw this" (hard rule)

When writing a **remarketing / retargeting** video script (the audience is warm — they've
already visited the page or watched a cold ad), **DO NOT open by naming their status.** This is a
hard ban. Banned openers (and any paraphrase of them):

- "คุณน่าจะเคยเข้าไปดูคอร์สนี้มาแล้ว แต่ยังไม่ตัดสินใจซื้อใช่ไหมครับ?"
- "เห็นว่าคุณสนใจคอร์ส… แต่ยังไม่ได้สมัคร"
- "กลับมาอีกครั้งนะครับ / ยังลังเลอยู่ใช่ไหม / ยังไม่ได้ตัดสินใจ"

Why it's bad: it breaks the fourth wall, feels like a tracking-bot calling them out, and wastes the
hook on a status they already know. It reads cheap.

**Instead, open tactically — let relevance do the work so it *feels* targeted without announcing it.** Pick one:
- Drop straight into the **single highest-tension pain or objection** the warm viewer is stuck on.
- A **concrete micro-story** ("ร้านนึงกำไรในกระดาษเดือนละแสน แต่สิ้นเดือนเงินไม่พอจ่ายเงินเดือน…").
- A **specific number / stat** that reframes the stakes.
- A **myth to bust** or a **new angle** that recontextualizes the same offer they already saw.
- The **one objection-killer** (price, time, "ทำเองไม่ได้หรอก", guarantee) hit head-on.

The warm viewer already knows the product — earn the re-watch with a sharper hook or a fresh angle,
never a "you didn't buy" callout. (Same applies to remarketing **captions/primary text**.)

## Hard rules (cause real problems if broken)

- Every scene has an **entrance** animation; **no exit animations except the final scene** — the
  transition IS the exit. (HyperFrames rule.)
- **No `repeat: -1`** — compute finite repeats: `Math.ceil(duration / cycle) - 1`.
- **No emoji / exotic glyphs in headline text** — they render as tofu boxes in headless Chrome.
  Build sparkles/icons as SVG or styled elements instead.
- **Center each scene's content group vertically.** Treat everything in a scene (visuals/key
  visual + headline + body, in their stacked order) as ONE block and center it vertically in the
  frame. Never pin content to the top or bottom edge — even when an element is conceptually "on top",
  it means top *within the centered group*, not top of the screen. Applies to every slide.
- **No orphan lines (esp. Thai) — RENDER-BLOCKING.** Audit every headline, prompt, label, and subtitle;
  a wrapped block must never drop a single lonely word or syllable onto its own final line. Fix it by
  exactly one of two sizing moves, whichever looks better for that clip: (1) **shrink** the font until
  the orphan rejoins the line above, or (2) **enlarge** the font until the final line carries roughly
  2–3 words/syllables. Verify on rendered snapshots and ask a fresh third-party AI to check the sampled
  frames — line breaks depend on the rendered font, not your guess. Any orphan blocks delivery.
- **No `Math.random()` / `Date.now()`** in the composition — use seeded values; renders must be deterministic.
- **No dead air — text on screen at ALL times except during a transition.** Every scene's first text
  element must enter within ~0.3s of the scene becoming active (right after its transition-in), carrying
  that scene's opening narration line. NEVER leave a gap longer than ~2s where the frame shows only a
  background / graphic / sticker with no readable text. A graphic-only beat under ~2s is fine; over ~2s
  is not (the user will reject it). The usual cause is timing a scene's first line to a *later* narration
  line and skipping the earlier one — add a synced line (a kicker is enough) for the skipped line instead
  of holding an empty frame. Verify by scrubbing/sampling frames between each scene's start and its first
  punch: if any non-transition timestamp has no text, fill it.
- **No static frames — every scene must keep moving (user is strict about this).** Dead air is about
  text *presence*; this is about *motion*. A scene that plays its entrance once then freezes until
  `leave()` reads flat — worst on the early text-only scenes (hook/opener). Give EVERY scene continuous
  low-amplitude FOREGROUND motion (image → `kb` Ken Burns; text-only → `floatGrp` ~±14px drift on its
  `.sc`) AND vary the entrance per scene (`tiltIn` / opposite-side semantic slides / `punch`+`glint` /
  letter-spacing open) instead of one flat fade everywhere — background breathing alone is not enough.
  See the helpers + the "No static scene" rule in `references/animation.md`. Verify: scrub each scene —
  any >1.5s stretch with zero foreground movement must be fixed.
- **No bare slide — every scene carries visual substance (user is very strict: "อย่างน้อยต้องมี kv").**
  A scene that is just a flat colour field + text is a defect. Every scene needs, in priority order:
  1. **A key visual.** Aim for a KV on (nearly) **every** slide — a product/salepage image, a cutout, an
     instructor/mascot, a screenshot, a drawn diagram/chart. **Refresh a NEW KV every 1–3 scenes** (many
     KVs + slight float is exactly what reads as "not static" — the user's most-praised move). Pull assets
     **from the salepage first** (download the whole set up front) before generating new ones.
  2. **Else, a faint stock-video background.** If a beat genuinely has no literal image (a definition, a
     pure framework line), it must NOT sit on flat colour — give it a **low-opacity stock-video bg
     (10–20%, tiled 2–4 clips, crossfaded)** per `techniques.md #2` as its living base.
  3. **Always, moving vector/graphic elements.** On top of (1) or (2), every scene gets animated vectors —
     boil stickers, SVG accents/icons, underline/strike wipes, draw-on lines, a rule, a chip. If a slide
     feels **โล่ง/empty or too text-heavy, add MORE elements** (salepage assets → SVG → boil stickers) until
     it reads as *artwork*, not a web page. Never a slide with nothing but a headline.
  Verify: scrub every scene — any scene showing **only flat background + text** (no KV, no stock-video base,
  no animated vector) is rejected and must be filled. ("Let a text beat breathe" means clean **+ textured +
  moving**, never bare — see `references/key-visual.md`.)
- **Verify every render** by viewing extracted frames. Treat cross-scene `inspect` overlaps and
  contrast warnings sampled while an element is hidden (opacity 0) as false positives — but prove it.
  Also scan for **dead air** (a non-transition stretch >2s with no text) and fix it.
- **NEVER skip the sound picker (Pipeline step 8).** Before mixing BGM/SFX onto the rendered video,
  you **MUST** present a playable `sound_picker.html` with `<audio controls>` for BGM candidates,
  per-beat SFX candidates, and 3 VO versions — then `open` it and **WAIT for the customer to pick**.
  You cannot hear audio. Do not self-select "sensible defaults" and proceed to the mix. Do not combine
  this step with rendering. Do not skip it because "the storyboard already had SFX previews". The
  storyboard previews are preliminary; the sound picker after render is the **final gate**. This is the
  single most commonly skipped step — treat it as seriously as the concept-pick gate (STEP 2).
- **Brand name spelling is exact and non-negotiable.** Reproduce each brand's name in its canonical
  form verbatim in any on-screen text you author. **For OntheWay Academy → always write `OntheWay Academy`**
  (one word `OntheWay`, capital O and W) — NEVER `On The Way Academy`, `ON THE WAY ACADEMY`, `Ontheway`, etc.
  (The brand's own logo / cover artwork may letter it differently — leave their official assets untouched;
  this rule governs text YOU set.) For any other brand, confirm the exact string from the user or the
  sale page and match it character-for-character — don't re-space or re-case a brand name.
- **TTS pronunciation text must never leak into visible subtitles.** The audio script may use Thai
  phonetics, but the final SRT and rendered subtitle DOM must use canonical brand/product spelling,
  acronyms, numbers, dates, quantities, and price notation. Treat `tts_script` and
  `display_subtitles` as separate required artifacts and block render until their normalization audit passes.

## References

- `references/onboarding.md` — **first-run setup**: verify/install HyperFrames (Node+FFmpeg) and connect the
  Google Gemini API key (TTS + images) — beginner-proof walkthrough for the packaged/sold skill.
- `references/dependencies.md` — **dependency manifest** (bundled vs auto vs required) + packaging notes.
- `references/models.md` — **self-healing model registry**: the pinned AI model IDs + the protocol to
  auto-research & rewrite them when a model is retired. · `scripts/setup.sh` self-check/heal · `scripts/cutout.py` no-rembg cutout.
- `references/technical-directions.md` — **the MECHANIC axis**: style-agnostic composition + motion +
  transition directions (TD1 Centered-KV+drifting-copy, TD2 full-bleed hard-cut, TD3 viewfinder+wipes, TD4
  UI/HUD reveal, TD5 character arc, TD6 split-screen + beat-level B1–B5). A video = **TD × style × palette**;
  pick the direction here, skin it with a preset/template. Read this to record a mechanic (not a look).
- `references/templates.md` — **full reusable VIDEO templates** (T1 Sitcom Pop …): complete `TD × style`
  instances (art direction + structure + KV method + audio) you can offer the customer as a pick or copy fast.
- `references/style-presets.md` — **the LOOK axis**: art directions (exact palettes, fonts, treatments) + how
  to derive a custom one. Skin any technical direction with one of these.
- `references/animation.md` — the reusable GSAP helper vocabulary (`enter/punch/leave/strike/popImg/kb/pulse/chatScene`) + animation rules.
- `references/techniques.md` — signature techniques: real-asset integration, background video layer, notebook/dot-grid texture, boil stickers, animated org-chart, chat balloons.
- `references/key-visual.md` — AI key-visual opener: 4 styles via Gemini Nano Banana Pro, intelligent background removal (rembg), the regenerate-until-clean retry loop, and first-frame placement.
- `references/audio.md` — sound layer: BGM + SFX from a free library (Mixkit), ffmpeg mixing recipe, **BGM fixed at 20%**, customer-picks-SFX-by-ear, and the storyboard SFX chooser.
- `references/workflow.md` — production discipline: **source-material analysis → `assets.json` (incl. video time-ranges)**, **storyboard mockup**, transcription & timing, asset prep (sale page + Pexels + fonts + resize), validation, frame verification, version snapshots.
