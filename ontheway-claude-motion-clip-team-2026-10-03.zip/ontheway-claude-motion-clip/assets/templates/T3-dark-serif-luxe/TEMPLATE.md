# Template 3 — "Dark Serif Luxe"

A restrained, premium, editorial look: a **near-black stage** lit by soft metallic glows, **serif display
headlines**, thin metal rules, framed proof, and a **glint sheen** on the numbers. No stickers, no boil —
the luxury is in the restraint. Reads as *premium, trustworthy, high-ticket, grown-up*. Reference build
(unbranded): `index.reference.html`. Poster/scene-flow show it realized on a real course ad.

> **This template is a TECHNIQUE, not a colour.** The DNA is dark stage + ONE metallic accent + serif
> display + thin rules + glint + framed assets. Swap gold for silver / bronze / champagne / any brand
> metal — the class stays.

**Emotion it buys:** premium, calm authority, "worth the money", trust. **Use it for** high-ticket /
serious / B2B / expertise / finance / luxury angles, and as the deliberate contrast piece in a set.
**Don't** use it for playful / cheap-and-cheerful / impulse angles (use **T2 Warm Halftone Poster** or
**T5 Y2K Neon Candy** there) — it is quiet on purpose.

## The DNA (what to keep — this is the template)

- **Surface / image style:** a **near-black** base lit by **two soft radial glows** in the accent colour
  (one top-centre ~16% alpha, one bottom ~6%), a **fine dot grain** (`radial-gradient(circle,#fff 1px…)`,
  `opacity ~.05`) that **drifts slowly**, and a **heavy vignette** (`transparent 50% → rgba(0,0,0,.62)`).
  The frame feels like a lit stage, not a flat card.
- **Type treatment — the signature move:** **serif display** for headlines (e.g. Trirong / any premium Thai
  serif), `line-height ~1.04`. Above them a **wide-tracked UPPERCASE kicker** in the accent
  (`letter-spacing:.34em;text-transform:uppercase`) — the couture label. **Thin metal rule** dividers
  (`width:120px;height:2px;linear-gradient(90deg,transparent,accent,transparent)`). Numbers/prices in the
  accent; big **price** carries a soft accent **glow** (`text-shadow:0 0 40px accent`). Strike-through uses a
  thin accent line.
- **KV / image-generation style:** every asset is **framed, not stickered** — `1px solid` accent border +
  `border-radius:8px` + a **large soft drop-shadow** (`box-shadow:0 30px 70px rgba(0,0,0,.7)`). Circular
  **avatar** with a thin accent ring. **Stat blocks** = a big accent number over a small cream label.
  Generate KV plates moody/premium (photoreal on dark, or product on black) — not bright cutouts.
- **Motion style — restrained:** entrances = **fade + rise** (`y:46 → 0`, `power2.out`), staggered ~0.13s.
  A **glint** (brightness 1→1.55 flash, ~0.5s) sweeps the hero number/price. Very **gentle float**
  (`y:-10`) on the group; **subtle Ken-Burns** (scale 1→1.05) on framed images; **fade-rise leave**
  (`y:-40`). Ambient grain drifts the whole time. **No boil, no stickers, no punch** — everything eases.
  Transitions: clean opacity crossfade between scenes.
- **Structure — 6-scene VO arc** (~1 line each): ① PAIN hook (a cost / a question) · ② TRUTH + saving
  (product framed) · ③ what you DON'T have to do · ④ premium output + speed **stats** · ⑤ **PROOF**
  (framed results) · ⑥ **CTA** + price (glow) + deadline + brand.
- **Format / audio:** 4:5 **1080×1350**, ~40–46s, VO-driven. Deep, sparse SFX (subtle), low BGM (~18–20%),
  premium mood — far fewer SFX hits than T2 (see `references/audio.md`).

## Colour = a parameter (example palette, swap freely)
```css
:root{ --bg:#0D0D10;  --bg2:#16151B;   /* near-black stage — swap for brand's darkest neutral */
       --accent:#C9A24B; --accent2:#E6CE8A; /* ONE metallic accent + its highlight (gold→silver/bronze/…) */
       --cream:#F2EDE3;                 /* off-white text */
       --dim:#8A8478; }                 /* muted label text */
```
Keep the ROLES (near-black base / one metallic accent + highlight / off-white text / muted dim). The look
holds in silver, bronze, champagne, deep-emerald-on-black, etc. — as long as the accent reads *metallic*.

## How to reuse (swap list — unbrand first)
Copy `index.reference.html` → swap these, keep structure + animation + textures:
1. **Unbrand** — replace `[BRAND]` / `[PRODUCT]` in the kicker, product frame, and CTA line.
2. **Palette** — retoken `--bg / --accent / --accent2 / --cream / --dim` (roles above).
3. **KVs** — regenerate the framed product plate + avatar (moody/premium); drop into the framed cards.
4. **Proof** — swap the results/screenshot (keep the 1px-border + soft-shadow frame), or make it generic.
5. **Copy/VO** — rewrite the 6-scene script (Gemini 3.6) + regenerate voice; re-time `data-start/duration`.
6. **SFX/BGM** — keep it sparse and deep; let the customer pick by ear.

Signature you must not lose: **dark stage + soft accent glows + serif display + wide-tracked kicker + thin
metal rules + framed (bordered, soft-shadow) assets + glint on numbers.** Hue, copy, assets are swappable.
