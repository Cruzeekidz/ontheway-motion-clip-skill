# Template 7 — "Cool Tech Neon Mono"

A HUD / terminal look: a **deep-navy blueprint grid**, **monospace** UI type with neon accents, drawn
interface elements (corner-bracket frames, checklists, progress bars, a flying cursor that clicks the CTA).
No photos — the product is rendered as a **schematic interface**. Reads as *techy, precise, modern,
systematic, "engineered"*. Reference build (unbranded): `index.reference.html`.

> **This template is a TECHNIQUE, not a colour.** The DNA is mono UI + blueprint grid + terminal labels +
> corner-bracket frames + a cursor-click finish. Swap cyan/mint for any neon pair on any dark base.

**Emotion it buys:** techy, futuristic, credible-modern, systematic. **Use it for** SaaS / apps / dev-tools
/ fintech / crypto / AI / online-course-in-tech / "a system, a method" angles. **Don't** use it for warm /
human / appetite angles (use **T2** or **T5**) — it is cool and schematic on purpose.

## The DNA (what to keep — this is the template)

- **Surface / image style:** a **deep navy** base with a **cyan blueprint grid** (two 1px `linear-gradient`
  line sets, `background-size:60px`) + a radial vignette (`::after`). HUD/terminal vibe throughout. **No
  photos** — every "asset" is drawn UI.
- **Type treatment — monospace UI:** a **monospace** face (e.g. Space Mono / any mono) for all English/UI at
  ~92px, in **neon** accents (cyan + mint). Thai body in a clean sans (Sarabun) at ~46px. **Terminal labels**
  set like filenames/commands — `> LABEL.EXE`, `> STEP_BY_STEP.SYS`, `> BUILD.RAW`. Everything reads as a
  console.
- **Interface elements (the KV method) — draw, don't photograph:** a **corner-bracket frame** (`.frame`, 2px
  neon border + four L-shaped `.cor` corners) around the logo/hero; **checklist rows** with `[✓]` boxes;
  **translucent grid blocks** (`rgba(accent,.08)`) as a 2×2 feature/tag grid; a **bordered progress bar** with
  a **count-up %**; a neon **CTA button**. The product's value is shown as a schematic, not a screenshot.
- **Signature finish — the cursor click:** an animated SVG **mouse cursor** (`.cursor`) flies in on a path and
  **clicks the CTA**, triggering a scale-pulse + a neon `box-shadow` flash on the button. Great closer.
- **Motion style — smooth & controlled:** soft **`power1/power2` fades** (not hard cuts), **`back.out`
  scale-ins** for the frame/blocks, a **letter-spacing collapse** on the logo (`24px → 2px`), **staggered
  tick-ins** on the checklist, a **2.2s progress fill** with a synced `onUpdate` number counter, and the
  cursor **path tween** (`power2.inOut`) into the click pulse. Precise, techy, never janky.
- **Structure — ~5 scenes:** boot/logo (`SYSTEM_INIT`) → the steps/checklist → the build/portfolio grid →
  the progress/result % → CTA (cursor clicks `REGISTER_NOW`).
- **Format / audio:** 4:5 **1080×1350**, ~24–28s, VO-driven. Clean electronic/synth BGM ~20% + UI blips /
  keystroke / soft click SFX on ticks and the cursor click (see `references/audio.md`).

## Colour = a parameter (example palette, swap freely)
```css
:root{ --bg:#0a1838;    /* deep navy base — swap for any dark tech hue */
       --accent:#4fd1ff;/* neon primary (cyan) — grid, borders, labels */
       --accent2:#7fffd0;/* neon secondary (mint) — CTA, highlights, count-up */
       --ink:#eaf6ff; }  /* near-white UI text */
```
Keep the ROLES (dark base / neon primary / neon secondary / near-white text). Any neon pair works — the mono +
grid + terminal labels are what read as "tech", not the specific cyan.

## How to reuse (swap list — unbrand first)
Copy `index.reference.html` → swap these, keep structure + UI elements + animation:
1. **Unbrand** — replace `[BRAND]` / `[PRODUCT]` in the framed logo + terminal labels + CTA.
2. **Palette** — retoken `--bg / --accent / --accent2 / --ink` (roles above).
3. **UI content** — rewrite the checklist steps, the 2×2 tag/feature grid, the `> LABEL` filenames, the
   progress % target — to the real product. (No image generation needed — it's all drawn.)
4. **Copy/VO** — rewrite the ~5-scene script (Gemini 3.6) + regenerate voice; re-time `data-start/duration`.
5. **Cursor** — keep the fly-in + click on the CTA; re-time it to land on the closing VO word.
   **Render note:** the progress **bar** animates render-safe (`scaleX`), but a JS `textContent` count-up on
   the **%** digits can render frozen under the seek-based renderer — verify on extracted frames; if it
   freezes, reveal the final % with a pop instead of counting (see `techniques.md #7`).
6. **SFX/BGM** — UI blips + a soft click on the cursor; clean synth bed.

Signature you must not lose: **mono UI + blueprint grid + terminal `> LABEL.EXE` labels + corner-bracket
frames + checklist/progress-bar/count-up + the flying cursor that clicks the CTA.** Hue, copy, steps swappable.
