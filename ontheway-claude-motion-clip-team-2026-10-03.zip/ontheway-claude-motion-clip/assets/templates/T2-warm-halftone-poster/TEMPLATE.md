# Template 2 — "Warm Halftone Poster"

A loud-but-warm **printed-poster / risograph** look: one flat warm background under a **halftone dot
screen**, oversized chunky sans type with a **hard offset "misregistration" shadow**, product/proof in
**hard-shadow bordered cards**, and **boil stickers** wobbling throughout. Reads as *handmade, energetic,
affordable, friendly*. Reference build (unbranded): `index.reference.html`. Poster/scene-flow show the style
realized on a real course ad.

> **This template is a TECHNIQUE, not a colour.** The DNA is the halftone screen + offset-shadow pop +
> boil stickers + chunky display type — it survives any palette. Ship it in any brand's colours; the
> example tokens below are just a starting hue.

**Emotion it buys:** playful, high-energy, "cheap-and-cheerful", human/handmade. **Use it for** mass /
self-serve / promo / value angles (food, retail, delivery, courses-for-everyone, tools, "do it yourself").
**Don't** use it for premium / high-ticket / serious-trust angles — it is loud on purpose (use **T3 Dark
Serif Luxe** or **T4 Minimal Editorial Index** there).

## The DNA (what to keep — this is the template)

- **Surface / image style:** ONE flat warm background (a solid, not a gradient sweep, not rotating). Over it,
  three stacked full-frame texture layers that make the "printed" feel:
  1. `.halftone` — radial-dot screen (`radial-gradient(circle, ink 2px, transparent 2.4px)`, size ~26px),
     `opacity .10`, **drifting slowly** (`x/y` to ~26px over the whole duration).
  2. `.grain` — fine horizontal line grain (`repeating-linear-gradient`), `opacity ~.06`.
  3. `.vig` — soft vignette to seat the type.
- **Type treatment — the signature move:** oversized **chunky geometric sans** display (heavy 800–900, e.g.
  Kanit / Anton / any bold Thai display), `line-height ~.96`, and a **hard offset drop-shadow**
  `text-shadow: 6px 6px 0 var(--ink)` on hero words (class `.mis`) — the "misregistration" pop. Small rotations
  (±2–4°) on a word or two. **Highlight chip** = accent-fill, paper text, rounded. **Strike-through** old price.
  **Giant price** = huge sans + offset shadow + `.baht` superscript.
- **KV / image-generation style:** photoreal **cutouts** (product, pack, device) and a **circular avatar**, each
  seated in / wearing a **hard offset shadow + solid border** (`box-shadow:12px 16px 0 ink; border:3px solid ink`)
  so every asset reads like a printed sticker / polaroid. Proof screenshots go in the **same** hard-shadow card.
  (Generate cutouts with `gemini-3-pro-image` on plain white → flood-fill cut; see `scripts/cutout.py`.)
- **Decorative boil stickers:** 2–4 small SVGs (star, clock, sparkle, pin) doing the **2-frame boil** (`.fa`/`.fb`
  opacity swap on `steps(1)` yoyo) — `data-layout-ignore`, ≤15% of frame. These carry the handmade life; keep them.
- **Motion style:** punchy, not floaty. Entrances = **slide-in-from-side** (`x:96`) OR **scale-pop**
  (`back.out(1.7)`), staggered ~0.12s per `.ln` line. **Gentle perpetual float** on the scene group. **Ken-Burns**
  (scale 1→1.07) on KV/screenshots. **Glint** (brightness flash) + **pulse** on hero numbers/price. Slide-out
  **leave** (`x:-130`). Boil loops the whole time; halftone drifts. Every scene keeps moving; text always on screen.
- **Structure — 6-scene VO arc** (~1 line each): ① HOOK (number/pain + a slam) · ② PRODUCT reveal + name ·
  ③ core BENEFIT (saving / speed) · ④ AUTHORITY + PROOF (avatar + results screenshot) · ⑤ PAYOFF (the promise) ·
  ⑥ CTA + price + deadline + brand.
- **Format / audio:** 4:5 **1080×1350**, ~40–48s, VO-driven. Upbeat BGM at fixed ~20% + **Thai-familiar SFX**
  balanced, spread ~1/scene, **≤30%** of duration, fade every trim (see `references/audio.md`).

## Colour = a parameter (example palette, swap freely)
```css
:root{ --paper:#F2E7D3;  /* flat warm bg — swap to brand's light/warm base */
       --ink:#171310;    /* near-black — offset shadows, body, borders */
       --accent:#E8521E; /* ONE hot accent — highlights, price, boil */
       --accent2:#F6892F;/* boil second-frame / warm secondary */
       --support:#117768;/* one supporting colour (badge/icon) — optional */ }
```
Keep the ROLES (flat base / near-black ink for the offset shadow / one hot accent / one support), change the hues.
A cool or dark base works too — as long as the offset shadow stays high-contrast against the type.

## How to reuse (swap list — unbrand first)
Copy `index.reference.html` → swap these, keep structure + animation + textures:
1. **Unbrand** — replace the brand chip text, CTA brand line, and product name (`[BRAND]`, `[PRODUCT]` in the shell).
2. **Palette** — retoken `--paper / --ink / --accent / --accent2 / --support` to the brand (roles above).
3. **KVs** — regenerate the product/pack cutout(s) + avatar; drop into the hard-shadow cards (`assets/…`).
4. **Proof** — swap the results/screenshot image (keep it in the bordered offset-shadow card, or make it generic).
5. **Copy/VO** — rewrite the 6-scene script (Gemini 3.6) + regenerate voice; re-time the scene `data-start/duration`.
6. **SFX/BGM** — re-map to the new beats; let the customer pick by ear.

Signature you must not lose: **halftone screen + `text-shadow:Npx Npx 0` offset pop + hard-shadow bordered cards
+ boil stickers + chunky heavy display type.** Everything else (hue, copy, assets) is swappable.
