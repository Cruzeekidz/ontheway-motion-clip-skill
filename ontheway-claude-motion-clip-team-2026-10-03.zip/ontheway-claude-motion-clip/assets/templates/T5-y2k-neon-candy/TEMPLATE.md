# Template 5 — "Y2K Neon Candy"

A loud, sugar-rush, marketplace look: a **saturated candy background** under comic-print halftone, photos
mounted on **cream torn-paper cards**, rounded chunky Thai type with a **double stacked hard shadow**,
highlighter chips, star-rating review bubbles, and scattered **SVG stars** — all moving with a deliberately
**janky stop-motion** jitter. Reads as *fun, impulsive, youthful, "shopee-seller energy"*. Reference build
(unbranded): `index.reference.html`.

> **This template is a TECHNIQUE, not a colour.** The DNA is torn-paper photo cards + double hard-shadow
> rounded type + halftone + scattered stars + stop-motion jitter. Swap magenta/lime/yellow for any 2–3
> saturated candy hues — the sugar-rush holds.

**Emotion it buys:** fun, energetic, impulse, young, cheap-and-cheerful. **Use it for** e-commerce /
marketplace / fashion / snacks / gadgets / flash-sale / Gen-Z impulse angles. **Don't** use it for premium
or serious-trust angles (use **T3 Dark Serif Luxe** or **T4 Minimal Editorial Index**) — it is maximal on
purpose.

## The DNA (what to keep — this is the template)

- **Surface / image style:** ONE **saturated candy** flat fill (hot magenta in the reference) overlaid with a
  **comic-print halftone** (`radial-gradient(circle …)`, `background-size:26px`, `opacity:.10`). Optional
  scattered **SVG stars** injected at ~9 fixed positions as a z-8 confetti layer.
- **KV / image-generation style — the signature mount:** every photo sits on a **cream "torn-paper" card** —
  a `.paper` element with a ragged multi-point `clip-path` polygon (deckle edge) + a **hard offset shadow**
  (`box-shadow:10px 12px 0 rgba(0,0,0,.35)`), image `object-fit:cover` inside, tilted a few degrees. Product
  photos read like clippings pasted into a scrapbook. Generate bright, high-key product shots (plain bg) →
  drop into the torn-paper card.
- **Type treatment — double stacked shadow:** rounded chunky Thai display (e.g. Mali / any rounded bold) at
  ~108px with **two stacked hard shadows** in `--ink` then `--accent2`
  (`text-shadow:5px 5px 0 #111, 8px 8px 0 var(--accent2)`) + `-webkit-text-stroke:2px #111`. **Highlighter
  chips** (`.hl`, accent-fill behind a word). **Typewriter sticker tags** (a mono font) rotated ~−3°.
  **Star-rating review bubbles** (black speech-bubble cards with ★★★★★ runs) for social proof. Pill CTA
  buttons in a contrasting bright colour.
- **Motion style — stop-motion jank (on purpose):** hard **`ease:"steps(1)"`** opacity cuts, constant
  low-amplitude **rotation jitter** on stars + paper cards (`steps(1)`, yoyo, finite repeat), **`back.out(2.4)`**
  pop-ins for cards, `back.out(1.8)` slide-ins. It should feel handmade and a little wobbly — not smooth.
- **Structure — ~5 fast scenes:** hook → hero product (torn-paper) → social proof (review bubbles) → range /
  more product → CTA (chat / order pill). Punchy, quick.
- **Format / audio:** 4:5 **1080×1350**, ~18–24s, VO-driven. Bouncy pop/EDM BGM ~20% + playful Thai-meme
  SFX, spread ≤30% (see `references/audio.md`).

## Colour = a parameter (example palette, swap freely)
```css
:root{ --bg:#ff2d8e;    /* saturated candy base — swap for any hot brand hue */
       --accent:#c2f032; /* a clashing second candy (lime) — CTA / shadow 2 / chips */
       --accent2:#c2f032;/* the second hard-shadow colour (can match --accent) */
       --pop:#ffe14d;   /* a third candy pop (yellow) — highlighter chips */
       --ink:#111;  --cream:#FFF6E6; } /* black for stroke/shadow 1, cream for torn-paper cards */
```
Keep the ROLES (2–3 clashing saturated candies / black stroke+shadow / cream card). Any loud combo works —
the louder and more clashing, the more "Y2K" it reads.

## How to reuse (swap list — unbrand first)
Copy `index.reference.html` → swap these, keep structure + animation + treatments:
1. **Unbrand** — replace `[BRAND]` / `[PRODUCT]` and CTA text.
2. **Palette** — retoken to 2–3 clashing candy hues + black + cream (roles above).
3. **KVs** — generate bright high-key product photos; drop into the torn-paper cards (keep the ragged clip-path).
4. **Proof** — rewrite the ★★★★★ review bubble copy (or swap for real screenshots on torn paper).
5. **Copy/VO** — rewrite the ~5-scene script (Gemini 3.6) + regenerate voice; re-time `data-start/duration`.
6. **SFX/BGM** — bouncy + playful; let the customer pick by ear.

Signature you must not lose: **torn-paper photo cards + double stacked hard-shadow rounded type + halftone +
scattered stars + stop-motion `steps(1)` jitter.** Hue, copy, product are swappable.
