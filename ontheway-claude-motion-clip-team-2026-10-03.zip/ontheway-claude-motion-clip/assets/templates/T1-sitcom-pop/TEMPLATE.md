# Template 1 — "Sitcom Pop"

A bright, comedic, fast-cut consumer ad. Saturated rotating-color backgrounds, big bold Thai type,
a **consistent cartoon character** carried across scenes, photoreal food/product KVs, boil stickers,
Thai-meme SFX. Built for **mass / appetite / fun** brands (food, café, retail, delivery, promos).
First built for ส้มตำแซ่บนัว "มื้อเที่ยงกู้ชีพ 40฿". Reference build: `index.reference.html`.

**Use it when:** the tone is playful/funny/appetite-driven and the audience is broad. **Don't** use it for
premium/serious/high-stakes (use Cinematic Photoreal E) — it is loud on purpose.

## Spec
- **Format:** 4:5 **1080×1350**, ~20–34s, VO-driven.
- **Backgrounds:** one **saturated solid** per scene, **rotated through a palette** (red → yellow → green
  → orange → yellow → red), each a soft radial. Over it: a big **sunburst rays** layer + faint halftone dots.
  - Sunburst: `.rays` sized **≈3× the frame** (`inset:-100%`), conic `at 50% 50%`, `opacity .10`, **spun about
    its center** (`transformOrigin:"50% 50%"`) — sized this large so a rotating edge NEVER shows. (A smaller
    rays box reveals corners mid-spin — the bug we fixed.)
- **Type:** Kanit **Black (900)** huge headlines, `line-height~1.04`, dark drop-shadow; color roles
  white / `--yellow` / `--ink`; `-webkit-text-stroke` for the pop outline. Price = giant Kanit + stroke +
  `.baht` superscript. **Brand chip** = ink bg, white, rounded, hard shadow. No eyebrows/tiny labels.
- **KV method — THE signature move: ONE character sheet → consistent face.**
  Generate a **2×2 character reference sheet** with `gemini-3-pro-image` (same person, 4 expressions —
  e.g. crying / shocked / eating-blissful / thumbs-up — on a **plain white** bg, identical face+hair+outfit).
  Flood-fill-cut the white bg into 4 transparent KVs (BFS from borders; see below). Reuse one expression per
  scene so the character is the **same person throughout**. Plus **photoreal food/product KVs** (cutout) per item.
- **Motion:** `kvIn` (back.out pop + gentle float), `rise/pop/bump` entrances, **boil stickers** (fa/fb 2-frame
  swap, e.g. chili/sparkle/"ปัง!"), sunburst spin. Every scene keeps moving; no dead air; text on screen always.
- **Structure — 6-scene sitcom arc** (~1 VO line each): ① HOOK comedic pain + a slam/punch · ② hero
  product + **price** · ③ appetite/quality peak (close-up freshness) · ④ menu/range expansion (more value) ·
  ⑤ **payoff** (close the comedic loop — same character now delighted) · ⑥ **CTA** + brand + delivery logos.
- **Audio (see `references/audio.md`):** VO (gemini-tts) + **BGM from a free library at fixed 20%** +
  **Thai-familiar SFX** from `assets/soundfxs/`, **balanced** (peak-normalize ~−9 dB each), **spread ~1 per
  scene (≥3–4s apart)**, **≤30%** of duration, **fade-out** every trim. Default BGM mood: upbeat funk/disco.

## How to reuse (swap list)
Copy `index.reference.html` → swap these, keep the rest:
1. **Brand** — name in the chip + CTA (exact spelling).
2. **Character sheet** — regenerate the 2×2 sheet for the new persona/business, re-cut 4 KVs.
3. **Product KVs** — generate the new food/product cutouts; replace `img/…`.
4. **Copy/VO** — rewrite the 6-scene script (Gemini 3.6) + regenerate voice; re-time.
5. **Palette** — keep the rotation or shift hues to the brand; the structure/animation stay.
6. **SFX/BGM** — re-map from `assets/soundfxs/` to the new beats (let the customer pick by ear).

## Cutout recipe (no rembg needed)
2×2 sheet → crop quadrants → BFS flood-fill from the borders over near-white pixels (`R,G,B ≥ ~232`) → set
alpha 0 → autocrop to the figure bbox + small margin. (Pure PIL; the working script is in the d1 project.)
