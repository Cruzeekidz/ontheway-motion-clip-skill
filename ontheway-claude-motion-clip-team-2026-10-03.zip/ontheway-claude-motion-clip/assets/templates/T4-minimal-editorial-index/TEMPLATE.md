# Template 4 — "Minimal Editorial Index"

A cool, modern, design-studio look: a **light neutral page** with a faint grid, a **viewfinder frame**
(corner ticks) and a **scene-index counter** (`01 / 06`), geometric type, ONE accent, and **wipe reveals**
(an underline bar or a strike sliding in on cue). Restrained and confident — the opposite of loud. Reads as
*modern, credible, systematic, "we know what we're doing"*. Reference build (unbranded):
`index.reference.html`.

> **This template is a TECHNIQUE, not a colour.** The DNA is the light neutral page + faint grid +
> viewfinder ticks + scene counter + single-accent **wipe** reveals + hard-offset framed proof. Swap the
> one accent to any brand hue — the system holds.

**Emotion it buys:** modern, minimal, credible, calm-confident, "design-forward". **Use it for** SME /
service / portfolio / clean-brand / considered-purchase angles, or as the quiet, raw contrast piece in a set.
**Don't** use it for loud impulse / appetite angles (use **T2** or **T5**) — it is deliberately spare.

## The DNA (what to keep — this is the template)

- **Surface / image style:** a **light warm-neutral** page (`#E7E5DF`-ish) with a **faint square grid**
  (`linear-gradient` lines, `opacity ~.05`) that **drifts slowly**. Two framing devices sell the "editorial
  index" feel: a thin **inner frame edge** (`.frameedge`, `inset:34px;border:1.5px solid rgba(ink,.22)`) and
  **four corner ticks** (`.tick` L-shapes at each corner) — a viewfinder. A **scene counter** sits top-left:
  `01 / 06` (`.idx`, accent number + dim `/ total`).
- **Type treatment:** geometric/techy sans (e.g. Bai Jamjuree / any modern grotesque) 700/600 for headlines,
  clean sans body; **uppercase tracked kicker** in dim grey (`letter-spacing:.16em`). Colour is mostly
  ink-on-neutral with **ONE accent** used surgically (a word, the price, a wipe bar). Big **stat numbers**
  (~140px). **Price** = huge accent.
- **Signature move — WIPE reveals synced to VO:** key phrases get an **underline bar** behind them that
  wipes in on cue (`.ubar{transform:scaleX(0);transform-origin:left}` → `scaleX:1`), and an old cost gets a
  **strike wipe** (`.x` bar `scaleX 0→1` crossing it out). The words are present from the scene start; only
  the accent bar animates when the VO hits the beat. This is the template's heartbeat.
- **KV / image-generation style:** framed flat and **hard**, not soft — `2px solid ink` border + a **hard
  offset shadow** (`box-shadow:14px 14px 0 rgba(ink,.16)`). No glow, no gloss. Screenshots/proof and product
  plates use the same frame. Keep KVs clean and literal.
- **Motion style — clean:** entrances = **rise + fade** (`y:40 → 0`, `power3.out`), staggered ~0.12s;
  **wipe** reveals (`power2.inOut`, ~0.34s); **subtle Ken-Burns** (scale 1→1.06) on framed images; a
  **gentle float** on the group; **slide-out leave** (`x:-120`). Grid drifts throughout. **No stickers, no
  boil, no glint** — the wipes and the counter carry the rhythm. Transitions: quick opacity + slide.
- **Structure — 6 indexed scenes** (the counter advances `01 → 06`): ① promise / a short list revealed by
  sequential underline wipes · ② product + name · ③ proof-of-capability **stats** · ④ cost struck out →
  the low number · ⑤ **PROOF** (framed results) · ⑥ **CTA** + price + deadline + brand.
- **Format / audio:** 4:5 **1080×1350**, ~45–55s, VO-driven. Minimal, dry SFX (a soft click / typewriter on
  the wipes), low BGM (~18–20%) — sparse, like T3 (see `references/audio.md`).

## Colour = a parameter (example palette, swap freely)
```css
:root{ --paper:#E7E5DF;  /* light warm-neutral page — swap for brand's lightest neutral */
       --ink:#17171B;    /* near-black — text, borders, hard offset shadow, grid */
       --accent:#E8521E; /* THE single accent — wipe bars, price, one hot word */
       --dim:#6f6c64; }  /* muted grey — kicker, labels, counter total */
```
Keep the ROLES (light neutral page / near-black ink / ONE accent / muted dim). Any accent hue works —
the accent is used so sparingly that the page stays calm whatever colour you pick.

## How to reuse (swap list — unbrand first)
Copy `index.reference.html` → swap these, keep structure + animation + framing devices:
1. **Unbrand** — replace `[BRAND]` / `[PRODUCT]` in the kicker, product frame, and CTA line.
2. **Palette** — retoken `--paper / --ink / --accent / --dim` (roles above).
3. **KVs** — regenerate clean product plate + proof screenshot; drop into the `2px + 14px-offset` frames.
4. **Copy/VO** — rewrite the 6 indexed scenes (Gemini 3.6) + regenerate voice; re-time `data-start/duration`.
   Re-place the `.ubar` / `.x` **wipe** cues to land on the exact VO word (this is the effect that sells it).
5. **Counter** — keep `NN / TOTAL`; update total if scene count changes.
6. **SFX/BGM** — keep it dry and minimal; a soft click on each wipe reads well.

Signature you must not lose: **light neutral + faint grid + viewfinder frame-edge + corner ticks + scene
counter + single-accent underline/strike WIPE reveals + hard-offset (`Npx Npx 0`) framed assets.** Hue,
copy, assets are swappable.
