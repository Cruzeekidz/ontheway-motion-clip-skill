# Template 6 — "Cinematic Bold Type"

A trailer-grade, high-energy look: **full-bleed graded photo plates**, **condensed uppercase** display
captions with one accent word, a glowing accent progress bar, and **hard-cut, punch-zoom** motion. Reads as
*intense, athletic, premium-gritty, "watch this"*. Reference build (unbranded): `index.reference.html`.
Poster/scene-flow show it realized on a fitness ad.

> **This template is a TECHNIQUE, not a colour.** The DNA is full-bleed monochrome-plus-one-accent photo
> grading + condensed-caps captions + punch-zoom hard cuts. Swap orange for any single hot accent — the
> trailer energy holds.

**Emotion it buys:** intense, motivational, bold, premium-gritty, cinematic. **Use it for** fitness /
sport / streetwear / automotive / energy / bold-brand / "transformation" angles, and anywhere you want a
hype trailer. **Don't** use it for gentle / playful / soft angles (use **T5** or **T2**) — it is aggressive
on purpose. (Related to Preset E *Cinematic Photoreal*, but louder: condensed-caps + hard cuts + accent bar.)

## The DNA (what to keep — this is the template)

- **Surface / image style — full-bleed graded plates:** every scene is a **full-frame photo** (`object-fit:cover`)
  pushed through a cinematic grade: `filter:grayscale(.65) contrast(1.18) brightness(.78)`, an accent
  **`mix-blend-mode:color` tint** layer (`.tint`, opacity ~.30), and a radial **vignette** (`.vig`). The photo
  IS the frame — never inset, never bordered. Generate moody, high-contrast photoreal plates (a subject in a
  gritty environment) with generous dark space for the caption.
- **Type treatment — condensed caps:** a **condensed uppercase** display (e.g. Anton / any tall condensed) at
  ~140px, `letter-spacing:2px`, `text-transform:uppercase`, with **one word accented** (`.o`, accent colour).
  Tracked-out sans sublines (small, wide letter-spacing). A giant **brand lockup** (~188px) with a soft accent
  **glow** + **hard offset shadow** (`text-shadow:0 0 40px accent, 6px 8px 0 #000`).
- **Decorative:** a single glowing **accent progress bar** (`.bar`) that wipes across low in the frame with a
  neon bloom (`box-shadow:0 0 24px accent`). Otherwise restraint — no illustrations, no stickers. The photo
  grade + the type carry it.
- **Motion style — hard-cut trailer:** scene changes are **hard `steps(1)` cuts** (~0.18s in / 0.12s out),
  each plate does a **Ken-Burns punch zoom** (`scale 1.14 → 1.0` on `power3.out`, then a slow drift to ~1.08),
  captions **scale-punch** in on `back.out(2)`, and caps/brand get a **6-frame `x:6` micro-shake**. Aggressive,
  percussive, cut-to-the-beat.
- **Structure — ~5 scenes:** cold-open line → escalating statement plates (the promise, the challenge) →
  brand lockup + CTA. Short lines, one thought per plate.
- **Format / audio:** 4:5 **1080×1350**, ~22–28s, VO-driven (or music-only). Cut to a driving beat; heavy
  impact SFX on the cuts, BGM louder than the calm templates (see `references/audio.md`).

## Colour = a parameter (example palette, swap freely)
```css
:root{ --bg:#0a0a0a;    /* near-black stage behind the plates */
       --accent:#ff5a1f;/* THE single hot accent — tint, accent word, bar, glow (swap freely) */
       --cream:#f5f1e8; }/* off-white caption text */
```
Keep the ROLES (near-black / ONE hot accent used everywhere / off-white text). The `mix-blend` tint means the
accent recolours the whole photo — pick the accent first, the grade follows.

## How to reuse (swap list — unbrand first)
Copy `index.reference.html` → swap these, keep structure + grade + animation:
1. **Unbrand** — replace `[BRAND]` in the lockup and `[CTA]`; rewrite the caption lines.
2. **Palette** — retoken `--accent` (the tint recolours everything) + `--bg` / `--cream`.
3. **Plates** — generate 4–5 moody full-bleed photoreal plates (subject + gritty environment, dark space for
   text); drop into `img/product*.png` slots. Keep the `grayscale/contrast/brightness` grade + tint + vignette.
4. **Copy/VO** — rewrite the ~5 short caption lines (Gemini 3.6) + regenerate voice; re-time `data-start/duration`.
5. **Beat** — re-place the hard cuts + progress bar to land on the music/VO beats.
6. **SFX/BGM** — driving + impactful; heavier than the other templates.

Signature you must not lose: **full-bleed grayscale-plus-accent-tint photo plates + condensed-caps captions
with one accent word + punch-zoom hard cuts + glowing accent bar.** Hue, copy, photos are swappable.
