#!/usr/bin/env bash
# ontheway-claude-motion-clip — first-run setup / self-check / self-heal.
# Portable: locates the skill from this script, prefers BUNDLED files, heals missing ones.
#
#   setup.sh             # full check + report (run on first use)
#   setup.sh --tts       # print the resolved tts.sh path (for the skill to call portably)
#   setup.sh --install-rembg   # optional: install rembg for photoreal cutouts
#
# Exit 0 = ready to produce. Exit 1 = something blocks producing (key/engine missing).
set -uo pipefail
SKILL="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
GLOBAL_SKILLS="$HOME/.agents/skills"
ok(){ printf '  \033[32m✅\033[0m %s\n' "$1"; }
no(){ printf '  \033[31m❌\033[0m %s\n' "$1"; }
warn(){ printf '  \033[33m⚠️\033[0m %s\n' "$1"; }

# --- resolve the bundled-or-global TTS helper (portable; prefer vendored) ---
resolve_tts(){
  for p in "$SKILL/vendor/gemini-tts/scripts/tts.sh" "$GLOBAL_SKILLS/gemini-tts/scripts/tts.sh"; do
    [ -f "$p" ] && { echo "$p"; return 0; }
  done
  return 1
}
resolve_gentts(){
  for p in "$SKILL/vendor/gemini-tts/scripts/generate_tts.py" "$GLOBAL_SKILLS/gemini-tts/scripts/generate_tts.py"; do
    [ -f "$p" ] && { echo "$p"; return 0; }
  done
  return 1
}
if [ "${1:-}" = "--tts" ]; then resolve_tts || { echo "MISSING" >&2; exit 1; }; exit 0; fi

# --- self-heal: if vendor TTS missing but global exists, restore the bundle ---
if [ ! -f "$SKILL/vendor/gemini-tts/scripts/generate_tts.py" ] && [ -f "$GLOBAL_SKILLS/gemini-tts/scripts/generate_tts.py" ]; then
  mkdir -p "$SKILL/vendor/gemini-tts/scripts"
  cp "$GLOBAL_SKILLS/gemini-tts/scripts/"{generate_tts.py,tts.sh} "$SKILL/vendor/gemini-tts/scripts/" 2>/dev/null
  chmod +x "$SKILL/vendor/gemini-tts/scripts/tts.sh" 2>/dev/null
  warn "self-heal: restored bundled gemini-tts from the global skill"
fi

if [ "${1:-}" = "--install-rembg" ]; then
  echo "Installing rembg (photoreal cutouts)…"
  python3.11 -m pip install --user "rembg[cli]" onnxruntime pillow || python3 -m pip install --user "rembg[cli]" onnxruntime pillow
  exit $?
fi

echo "── ontheway-claude-motion-clip setup check ──"
BLOCK=0

# 1) engine / system tools
echo "[1] Render engine + tools"
command -v node >/dev/null && { v=$(node -v); case "${v#v}" in 1[0-9].*|2[01].*) warn "node $v (need ≥ 22)";; *) ok "node $v";; esac; } || { no "node missing (install ≥22 from nodejs.org)"; BLOCK=1; }
command -v ffmpeg  >/dev/null && ok "ffmpeg"  || { no "ffmpeg missing (brew/winget/apt install ffmpeg)"; BLOCK=1; }
command -v ffprobe >/dev/null && ok "ffprobe" || no "ffprobe missing (ships with ffmpeg)"
command -v npx >/dev/null && ok "npx (→ npx hyperframes auto-installs)" || { no "npx missing (comes with node)"; BLOCK=1; }
command -v whisper-cli >/dev/null && ok "whisper-cli (VO timing)" || warn "whisper-cli not on PATH — hyperframes init/transcribe will fetch it"

# 2) python + cutout
echo "[2] Python + image tools"
command -v python3 >/dev/null && ok "python3" || { no "python3 missing"; BLOCK=1; }
python3 -c "import PIL" 2>/dev/null && ok "Pillow (PIL) — used by cutout.py" || no "Pillow missing: python3 -m pip install --user pillow"
python3 -c "import rembg" 2>/dev/null && ok "rembg (optional, photoreal cutouts)" || warn "rembg not installed — default cutout uses scripts/cutout.py (PIL only). For photoreal: setup.sh --install-rembg"

# 3) bundled assets
echo "[3] Bundled files"
[ -f "$SKILL/scripts/cutout.py" ] && ok "cutout.py" || no "scripts/cutout.py MISSING (re-pull the skill)"
[ -f "$SKILL/scripts/gen_key_visual.py" ] && ok "gen_key_visual.py" || warn "scripts/gen_key_visual.py missing (KV generator)"
[ -d "$SKILL/assets/soundfxs" ] && ok "assets/soundfxs ($(ls "$SKILL/assets/soundfxs"/*.mp3 2>/dev/null | wc -l | tr -d ' ') SFX)" || warn "assets/soundfxs missing (Thai SFX pack)"
[ -d "$SKILL/assets/templates" ] && ok "assets/templates" || warn "assets/templates missing"
TTS=$(resolve_tts) && ok "gemini-tts helper → ${TTS/#$HOME/~}" || { no "gemini-tts NOT found (vendor/ or global) — TTS will fail"; BLOCK=1; }

# 4) Gemini API key (TTS + images) — the real onboarding gate
echo "[4] Google Gemini API key (voiceover + images)"
GEN=$(resolve_gentts)
if [ -n "$GEN" ]; then
  TTS_LOG=$(mktemp "${TMPDIR:-/tmp}/ontheway-tts-check.XXXXXX")
  if python3 "$GEN" "ทดสอบเสียง" /tmp/_fva_tts_test.wav >/dev/null 2>"$TTS_LOG"; then
    ok "Gemini key works (TTS test passed) — key powers BOTH voice + images"
    rm -f /tmp/_fva_tts_test.wav
  elif grep -q "GEMINI_API_KEY not found" "$TTS_LOG"; then
    no "Gemini key NOT connected → see references/onboarding.md §B"
    echo "      Get a key: https://aistudio.google.com/apikey  → Create API key → copy the displayed key (currently commonly starts AQ…; prefixes may change)"
    echo "      Save it:  mkdir -p ~/.claude/secrets && printf 'GEMINI_API_KEY=%s\\n' \"YOUR_KEY\" > ~/.claude/secrets/gemini.env"
    BLOCK=1
  else
    no "Gemini key found, but the live TTS test failed"
    echo "      Reason: $(head -n 1 "$TTS_LOG")"
    echo "      Do NOT replace the key based on this message alone. Check network access, API permissions, quota, and the pinned model id."
    BLOCK=1
  fi
  rm -f "$TTS_LOG"
else
  no "cannot test key (TTS script unresolved)"; BLOCK=1
fi

# 5) model registry
echo "[5] Model registry"
[ -f "$SKILL/references/models.md" ] && ok "references/models.md (self-healing model ids)" || warn "references/models.md missing"

echo "──────────────────────────────"
if [ "$BLOCK" = 0 ]; then echo "✅ READY — go produce."; exit 0
else echo "❌ Setup incomplete — review the specific ❌ items above before producing."; exit 1; fi
