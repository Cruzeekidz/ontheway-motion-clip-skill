#!/usr/bin/env python3
"""Background-removal cutout using ONLY Pillow (no rembg / no numpy / no model download).

The skill's preferred no-dependency cutout: generate the subject on a PLAIN near-white background,
then this flood-fills the white from the borders to transparent and auto-crops to the subject.
Use this when rembg isn't installed (it's the path ontheway-claude-motion-clip uses by default).

Usage:
  python3 cutout.py in.png out.png [--threshold 232] [--margin 12]
  python3 cutout.py sheet.png out_prefix --grid 2x2   # cut a 2xN character sheet into N transparent KVs

Needs: Pillow only.  (For photoreal subjects on busy backgrounds, prefer rembg — see onboarding.md.)
"""
import sys, os
from collections import deque
try:
    from PIL import Image
except ImportError:
    sys.exit("Pillow required: python3 -m pip install --user pillow")


def floodcut(im, th=232, margin=12):
    im = im.convert("RGBA")
    w, h = im.size
    px = im.load()
    seen = bytearray(w * h)
    dq = deque()
    def white(x, y):
        r, g, b, a = px[x, y]
        return r >= th and g >= th and b >= th
    for x in range(w):
        for y in (0, h - 1):
            i = y * w + x
            if not seen[i] and white(x, y):
                seen[i] = 1; dq.append((x, y))
    for y in range(h):
        for x in (0, w - 1):
            i = y * w + x
            if not seen[i] and white(x, y):
                seen[i] = 1; dq.append((x, y))
    while dq:
        x, y = dq.popleft(); px[x, y] = (255, 255, 255, 0)
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            nx, ny = x + dx, y + dy
            if 0 <= nx < w and 0 <= ny < h:
                i = ny * w + nx
                if not seen[i] and white(nx, ny):
                    seen[i] = 1; dq.append((nx, ny))
    bb = im.getbbox()
    if bb:
        bb = (max(0, bb[0] - margin), max(0, bb[1] - margin),
              min(w, bb[2] + margin), min(h, bb[3] + margin))
        im = im.crop(bb)
    return im


def main():
    a = sys.argv[1:]
    if len(a) < 2:
        sys.exit(__doc__)
    src, out = a[0], a[1]
    th = int(a[a.index("--threshold") + 1]) if "--threshold" in a else 232
    margin = int(a[a.index("--margin") + 1]) if "--margin" in a else 12
    if "--grid" in a:
        gx, gy = (int(v) for v in a[a.index("--grid") + 1].lower().split("x"))
        im = Image.open(src).convert("RGBA"); W, H = im.size
        cw, ch = W // gx, H // gy
        n = 0
        for r in range(gy):
            for c in range(gx):
                q = im.crop((c * cw, r * ch, c * cw + cw, r * ch + ch))
                floodcut(q, th, margin).save(f"{out}_{n}.png"); n += 1
        print(f"cut {n} cells -> {out}_0..{n-1}.png")
    else:
        floodcut(Image.open(src), th, margin).save(out)
        print("saved", out)


if __name__ == "__main__":
    main()
