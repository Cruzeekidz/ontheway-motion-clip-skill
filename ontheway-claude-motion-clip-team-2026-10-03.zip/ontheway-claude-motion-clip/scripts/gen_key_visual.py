#!/usr/bin/env python3
"""Generate 4 key-visual styles with Gemini Nano Banana Pro, then optionally cut out the bg.

Usage:
  set -a; . ~/.config/google-genai/.env; set +a        # load GEMINI_API_KEY
  python3 gen_key_visual.py "CONCEPT sentence describing the scene" [outdir] [style_key ...]
    - no style keys -> all 4 (kv1_3d, kv2_flat, kv3_clay, kv4_duotone); else only the listed keys
  # then remove background (needs: python3.11 -m pip install --user "rembg[cli]" onnxruntime pillow):
  python3 gen_key_visual.py --cut outdir/kv4_duotone.png

The CONCEPT should describe the subject + a PLAIN simple background + "no text/logos/watermark"
and ask for a centered subject with generous margin (clean edges = clean cutout).
"""
import os, sys, json, base64, urllib.request, urllib.error

# Nano Banana 2 (gen-2 flash image) is the user's preferred default; Pro = gemini-3-pro-image.
# Verify the current id via the gemini-api catalog; override with KV_MODEL.
MODEL = os.environ.get("KV_MODEL", "gemini-3.1-flash-image")
ASPECT = os.environ.get("KV_ASPECT", "1:1")   # square — vertical KV leaves no room for text in a vertical video

STYLE_MOD = {
    "kv1_3d":   "A playful Pixar-like 3D rendered illustration, soft cinematic lighting, smooth rounded shapes, warm appealing colors. ",
    "kv2_flat": "A modern FLAT vector editorial illustration, limited bold palette, geometric and minimal, clean thick shapes. ",
    "kv3_clay": "A cute isometric clay / toy miniature diorama render, matte clay materials, soft studio lighting, warm and whimsical. ",
    "kv4_duotone": ("A PHOTOREALISTIC editorial photograph with a striking SELECTIVE-COLOR / duotone treatment: the whole scene "
                    "is high-contrast black & white EXCEPT one key object rendered in a single bold accent color (the only color "
                    "in the frame). Cinematic studio lighting, realistic texture, shallow depth of field. "),
}
TAIL = (" Subject centered, full body visible, generous empty margin. Plain SIMPLE solid flat background "
        "(single clean color), soft even lighting, crisp clean edges for easy cutout. No text, no logos, "
        "no watermark. Vertical composition.")


def gen(concept, name, outdir):
    key = os.environ["GEMINI_API_KEY"]
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{MODEL}:generateContent"
    body = {"contents": [{"parts": [{"text": STYLE_MOD[name] + concept + TAIL}]}],
            "generationConfig": {"responseModalities": ["IMAGE"], "imageConfig": {"aspectRatio": ASPECT}}}
    req = urllib.request.Request(url, data=json.dumps(body).encode(),
                                headers={"x-goog-api-key": key, "Content-Type": "application/json"})
    try:
        data = json.load(urllib.request.urlopen(req, timeout=180))
    except urllib.error.HTTPError as e:
        print(f"[{name}] HTTP {e.code}: {e.read().decode()[:300]}", file=sys.stderr); return False
    for p in data.get("candidates", [{}])[0].get("content", {}).get("parts", []):
        inline = p.get("inlineData") or p.get("inline_data")
        if inline and inline.get("data"):
            out = os.path.join(outdir, f"{name}.png")
            open(out, "wb").write(base64.b64decode(inline["data"]))
            print(f"[{name}] saved {out} ({os.path.getsize(out)//1024} KB)"); return True
    print(f"[{name}] no image: {json.dumps(data)[:300]}", file=sys.stderr); return False


def cut(path):
    """Remove background -> <name>_cutout.png + a preview composited on dark."""
    from rembg import remove, new_session
    from PIL import Image
    out = remove(Image.open(path), session=new_session("u2net"), post_process_mask=True)
    base = os.path.splitext(path)[0]
    out.save(base + "_cutout.png")
    bg = Image.new("RGBA", out.size, (10, 10, 10, 255))
    bg.alpha_composite(out.convert("RGBA"))
    bg.convert("RGB").save(base + "_preview_on_dark.png")
    import numpy as np
    alpha = np.array(out)[:, :, 3]
    print(f"cutout -> {base}_cutout.png  (transparent {(alpha==0).mean()*100:.1f}%)  preview -> {base}_preview_on_dark.png")
    print("If messy (leftover bg / halo / missing parts): regenerate THIS image with a plainer "
          "background and re-run --cut until clean.")


if __name__ == "__main__":
    a = sys.argv[1:]
    if a and a[0] == "--cut":
        cut(a[1]); sys.exit(0)
    concept = a[0]
    outdir = a[1] if len(a) > 1 and not a[1].startswith("kv") else "kv"
    want = [x for x in a if x.startswith("kv")] or list(STYLE_MOD)
    os.makedirs(outdir, exist_ok=True)
    ok = sum(gen(concept, k, outdir) for k in want)
    print(f"done: {ok}/{len(want)} images in {outdir}/")
