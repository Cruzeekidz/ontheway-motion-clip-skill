# Model registry — single source of truth (self-healing)

These are the **AI model IDs this skill depends on**. They are version-pinned, so when Google retires
or renames a preview model the skill would break. This file makes the IDs **self-healing**: on a
model error, the AI **researches the current model online and rewrites the row here** (and the locked
script if needed), then retries.

## Current models  (update the date when you change a row)
| capability | model id | used by | last verified |
|---|---|---|---|
| **Voiceover (TTS)** | `gemini-3.1-flash-tts-preview` | `vendor/gemini-tts/scripts/generate_tts.py` (ALLOWED_MODEL, **locked**) | 2026-06-22 |
| **Key visual / plate (image)** | `gemini-3-pro-image` | KV/plate generation | 2026-06-22 |
| **Image (fast / cheaper alt)** | `gemini-3.1-flash-image` | `scripts/gen_key_visual.py` default | 2026-06-22 |
| **Copywriting (VO/captions)** | `agy` default = Gemini 3.6 Flash High (free) → key fallback `gemini-3.6-flash` | `~/.config/google-genai/gemini-copy.sh` (agy-first; gemini-api) | 2026-07-02 |
| **AI video clip (optional)** | `veo-3.0-fast-generate-001` | optional hero shots | 2026-06-22 |

API host for all of the above: `https://generativelanguage.googleapis.com/v1beta`.

## 🔧 Self-healing protocol — when a model call FAILS
Trigger on errors like: `model not found` / `404` / `is not allowed` / `deprecated` / `no longer
available` / `unsupported model`, OR a TTS that errors out on the locked id.

1. **Identify** the failing capability + id from the table above.
2. **Discover the current id** two ways and cross-check:
   - **Live list (authoritative):** the user's key already works, so query the catalog:
     ```bash
     KEY=$(sed -nE 's/^(export )?(GEMINI_API_KEY|GOOGLE_API_KEY)=["'"']?([^"'"']+)["'"']?$/\3/p' ~/.claude/secrets/gemini.env ~/.config/google-genai/.env 2>/dev/null | head -1)
     curl -s "https://generativelanguage.googleapis.com/v1beta/models?key=$KEY&pageSize=300" \
       | python3 -c "import sys,json;[print(m['name'].replace('models/',''),'|',','.join(m.get('supportedGenerationMethods',[]))) for m in json.load(sys.stdin).get('models',[])]"
     ```
     Pick the newest id whose name matches the capability + supports the right method
     (`generateContent` for image/copy, `predictLongRunning` for veo; TTS ids contain `tts`).
   - **Web research:** `WebSearch` "latest Google Gemini <capability> model id 2026" to confirm the
     newest GA/preview name and any migration notes.
3. **Choose** the newest stable id (prefer GA over preview when equivalent).
4. **Record it HERE** — overwrite the row's `model id` + bump `last verified` to today + add a line under
   "History" with the old→new + reason. This file is the source of truth the skill reads.
5. **If the broken model is the locked TTS id**, also update `ALLOWED_MODEL` in
   `vendor/gemini-tts/scripts/generate_tts.py` (and the global gemini-tts copy) to the new id.
6. **Retry** the failed call with the new id. Tell the user what you changed.

> The point: the skill **fixes its own model drift** instead of dying — and the fix persists in this file
> so the next run already has the right id. Never hardcode a model id elsewhere; read it from this table.

## History
- 2026-06-22 — initial registry created (pins above).
