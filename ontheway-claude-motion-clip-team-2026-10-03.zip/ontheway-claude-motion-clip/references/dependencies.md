# Dependency manifest

Everything this skill needs, and whether it's **bundled** (ships in the skill), **auto** (installed/fetched
on demand), or **required** (the user/machine must provide). Run `scripts/setup.sh` to check all of this.

## Cross-skill (engine + voice)
| dep | role | status |
|---|---|---|
| **gemini-tts** scripts (`generate_tts.py`, `tts.sh`) | voiceover (TTS) | 🟢 **BUNDLED** at `vendor/gemini-tts/` (key-free). Falls back to global `~/.agents/skills/gemini-tts/`. `setup.sh` self-heals a missing bundle from the global copy. |
| **hyperframes** + **hyperframes-cli** | render engine (`npx hyperframes …`) | 🔵 AUTO — `npx hyperframes` installs on first call (needs Node ≥22 + FFmpeg). |
| hyperframes-media / -animation / -core / -creative | guidance refs (tts/transcribe/bgm, GSAP, contract) | 🔵 part of the hyperframes family |
| **gemini-api** (`~/.config/google-genai/gemini-copy.sh`) | copywriting via Gemini 3.6 — tries `agy` (free Gemini 3.6 Flash High) first, falls back to the AI Studio key on 429/quota | 🟡 REQUIRED for AI copy — optional if you write copy yourself. `agy` path needs no key; fallback uses the same key |

## System tools (machine)
| dep | role | status |
|---|---|---|
| **Node ≥ 22** | runs hyperframes | 🔴 REQUIRED (onboarding installs) |
| **FFmpeg / ffprobe** | encode + audio mix + timing | 🔴 REQUIRED |
| **whisper-cli** | VO → timing map | 🔵 AUTO (hyperframes fetches model) |
| **python3** + **Pillow (PIL)** | `cutout.py`, contact sheets, mixing helpers | 🔴 REQUIRED (PIL: `pip install pillow`) |
| **rembg** + onnxruntime + numpy | photoreal cutouts | 🟡 OPTIONAL — default cutout is `scripts/cutout.py` (PIL flood-fill, no rembg). Install only for hard photoreal cutouts: `setup.sh --install-rembg`. |
| curl, sips, cwebp | asset fetch/resize | 🔵 common/auto |

## APIs / keys
| service | role | key |
|---|---|---|
| **Gemini API** (`generativelanguage.googleapis.com`) | 🔴 voiceover + images + copy | **one key** at `~/.claude/secrets/gemini.env` → onboarding §B. Model ids live in `references/models.md` (self-healing). |
| **Mixkit** (`mixkit.co`) | BGM + SFX library | 🟢 free, no key |
| **Pexels** (`api.pexels.com`) | faint stock-video bg layer | 🟡 OPTIONAL key at `~/.config/pexels/key` |
| **jsDelivr CDN** | Thai/Latin fonts + GSAP runtime | 🔵 needs network at build/render |

## Bundled assets (ship with the skill)
- `vendor/gemini-tts/` — voiceover scripts (key-free)
- `scripts/` — `setup.sh` (self-check/heal), `cutout.py` (no-rembg cutout), `gen_key_visual.py` (KV gen)
- `assets/soundfxs/` — Thai-familiar SFX pack (14) · `assets/templates/` — reusable video templates
- `references/` — onboarding, models, audio, workflow, presets, templates, animation, techniques, key-visual

## Packaging notes (selling this skill)
- **Always ship `vendor/gemini-tts/` with it** — TTS is a hard dep and is now self-contained (no global skill needed).
- **No keys are bundled** — keys resolve only from the user's env / `~/.claude/secrets` / `~/.config/google-genai`.
- Paths are resolved **relative to the skill** (`setup.sh` locates itself); the global gemini-tts is a fallback, not a requirement.
- Model drift is handled by `references/models.md` self-healing — the skill repairs its own model ids.
