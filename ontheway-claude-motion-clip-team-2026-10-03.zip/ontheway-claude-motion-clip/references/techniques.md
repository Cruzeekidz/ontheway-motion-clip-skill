# Signature techniques

Reusable building blocks that make these ads feel crafted. Use them where the narration earns them —
don't pile them all into one clip.

## 1. Real-asset integration (the most important one)

Pull the product's own images from its sale page and show them at the right beat:
- **Course cover / product shot** — reveal when the product is first named. Show it **large —
  roughly 80% of the frame width** — every place it appears (intro + CTA). It's a hero, not a thumbnail.
- **In-class slides / screenshots** — show as "proof" during the argument that maps a slide's content.
  Frame them like a device (rounded corners, gold/subtle border, drop shadow) so they read as "inside".
- **Mascot / instructor portrait** — humanize; great in a circular avatar.

Card + image CSS (lets stickers/overflow hang over the edge):
```css
.shot{align-self:center;position:relative;overflow:visible;}
.shot img{display:block;width:864px;height:auto;border-radius:18px;   /* hero cover ≈80% of 1080 */
  box-shadow:0 26px 70px rgba(0,0,0,.7);border:1px solid rgba(245,241,232,.12);}
```
Animate with `popImg` (entrance) + `kb` (slow Ken Burns) so the still image breathes.

**Solid images bleeding through the bg video — KNOWN UNSOLVED ISSUE.** A product cover/photo can
read slightly see-through (the faint background video shows through it) even though the image is
opaque RGB with no CSS opacity. Pixel-sampling confirms it: the cover region renders *brighter* than
the source over a bright bg — i.e. light is being added from behind. A **solid backing div**
(`background:#0A0A0A` behind the image) *reduces* it but does **not** fully kill it. That rules out
alpha/opacity and points at a **non-Normal blend / compositing mode** in the render pipeline — the
foreground compositing over the bg-video track like a Photoshop "Screen/Burn" rather than "Normal".
TODO to investigate: `mix-blend-mode` / `isolation` on scenes and the `.bgvid` layer, and how the
renderer composites the video track vs the DOM scenes; try forcing `isolation:isolate` /
`mix-blend-mode:normal`, or drop the bg-video opacity to 0 behind full-bleed covers. Workaround for
now: place covers on the darkest bg moment. (Never apply backings to transparent cutouts like the
key visual — they're meant to float.)

## 2. Background video layer (stock footage — faint only)

Stock footage is texture, never the message. One or more dark/moody clips behind everything at
**opacity 10–20%**, darkened so type stays crisp.

```css
.bgvid{position:absolute;inset:0;z-index:0;pointer-events:none;overflow:hidden;opacity:0;}
.bgvid video{width:100%;height:100%;object-fit:cover;filter:brightness(.48) contrast(1.05) saturate(.8);}
#b1{opacity:.20;}
```
```html
<div class="bgvid" id="b1"><video id="vid1" data-start="0" data-duration="11.6" data-track-index="1"
  src="assets/seg1.mp4" muted playsinline></video></div>
```
- Each `<video>` needs its own `id`, `muted`, `playsinline`, and `data-start/duration/track-index`
  (audio is track 0; give each clip a distinct track index). Don't call `.play()` — the runtime seeks.
- **Tile multiple clips — MANDATORY, never one clip for the whole video.** Use **2–4 different** clips
  per ad and **crossfade** at the seams: fade the outgoing `#bN` to 0 and `fromTo` the incoming `#bN+1`
  to the base opacity over ~0.9s, centered on each boundary. **No single clip should span more than ~2
  scenes** — keep the footage changing so the background never feels dead/static. Pick clips longer than
  their segment so they never freeze. Source via Pexels (see workflow.md).
- **Across a series, never reuse a clip (or query) between videos.** Each ad gets its own SET of
  backgrounds — vary the Pexels search query per video so no two ads share footage.

## 3. Texture: notebook grid / dot grid + vignette

A near-invisible texture stops the background feeling dead.
```css
/* notebook grid (Editorial White), ~12% */
.grid{position:absolute;inset:0;z-index:1;pointer-events:none;opacity:.12;
  background-image:linear-gradient(rgba(74,16,24,.9) 1.5px, transparent 1.5px),
                   linear-gradient(90deg, rgba(74,16,24,.9) 1.5px, transparent 1.5px);
  background-size:56px 56px;}
/* dot grid (Dark Bold), ~5% */
.grid{...opacity:.05;background-image:radial-gradient(circle, rgba(245,241,232,.9) 1.4px, transparent 1.6px);
  background-size:46px 46px;}
.vig{position:absolute;inset:0;z-index:3;pointer-events:none;
  background:radial-gradient(ellipse 78% 62% at 50% 42%, rgba(0,0,0,0) 50%, rgba(0,0,0,.66) 100%);}
```

## 4. Boil stickers (stop-motion decoration)

Cute hand-made accents (washi tape, paper clip, sparkle) that "boil" like 2-frame stop motion —
**no positional movement**, just two SVG path variants swapped in place. Keep them to ≤15% of the
frame and `data-layout-ignore` so they don't trip the layout audit.
```js
var BOIL = 0.18, BR = Math.ceil(DURATION / BOIL) - 1;
tl.to(".fa", { opacity: 0, duration: BOIL, ease: "steps(1)", repeat: BR, yoyo: true }, 0);
tl.to(".fb", { opacity: 1, duration: BOIL, ease: "steps(1)", repeat: BR, yoyo: true }, 0);
```
Each sticker holds two near-identical SVG paths `.fa` (visible) and `.fb` (`opacity:0`); the swap
gives the wobble. Finite repeat only.

## 5. Animated org-chart / diagram

When the narration describes a structure (a buyer map, a process, a hierarchy), draw it for real —
nodes as styled divs, connectors as SVG paths animated with a line-draw:
```html
<svg class="lines"><path class="c1" d="..." pathLength="100" style="stroke-dasharray:100;stroke-dashoffset:100"/></svg>
```
```js
tl.to(".c1", { strokeDashoffset: 0, duration: 0.4, ease: "power1.inOut" }, t); // draws the line
```
Reveal nodes with small `pop`s, draw connectors between them in narration order, optionally pulse
the key node. Small text is OK here — the diagram is the point.

## 6. Chat balloons (AI assistant / testimonial / DM)

Recreate a chat to show an AI helper, a DM, or a testimonial — far better than a static screenshot.
- Circular avatar (gold/accent ring), name + subtitle header.
- **User bubble** (accent fill) aligned right; **reply bubble** (cream/paper, dark text) aligned left
  with a small avatar.
- **Typing dots** between them: three dots that bob (`stagger` + finite `repeat` yoyo), then fade as
  the reply pops in. Stack typing + reply absolutely in one `min-height` slot (mark
  `data-layout-allow-overlap`) so there's no layout jump.
- Pop bubbles in with `back.out`. Keep text short — it must be glanceable in 3–4s.

```css
.bubble{max-width:80%;padding:26px 32px;font-family:"Sarabun";font-weight:600;font-size:40px;line-height:1.3;border-radius:28px;}
.bubble.user{align-self:flex-end;background:var(--red);color:#fff;border-bottom-right-radius:9px;}
.bubble.ai{background:var(--paper);color:#1A1714;border-bottom-left-radius:9px;}
.replyslot{position:relative;align-self:stretch;min-height:236px;}
.replyslot .typing,.replyslot .airow{position:absolute;left:0;top:0;}
```
Note: the cream bubble + dark text reads ~14:1; a WCAG warning sampled while the bubble is hidden
(opacity 0) is a false positive — verify on a real frame.

## 7. Per-scene vector enrichment (every slide gets animated graphics)

The other limb of the **"No bare slide"** rule (SKILL.md): on top of the KV (or the faint stock-video bg),
**every scene carries animated vector/graphic elements** so none reads โล่ง/empty or "like a web page". This
is what the user means by *"ใส่ vector animations ทุก slide"* and *"elements น้อยไป → เอา svg / boil sticker
มาเพิ่ม"*. A text-only scene on flat colour is a defect; enrich it until it reads as **artwork**.

Per-scene vector kit — sprinkle 1–3 that fit the beat:
- **Draw-on accents** on the key word/number: an **underline sweep**, a **▼ drop arrow**, a **hand-drawn
  circle/scribble**, a short **rule**.
- **Icons / props** tied to the message (finance icons, a shield, a clock, a wallet, a spark), as SVG.
- **Ratings / rows / meters**: a 5★ row, a module/step row, a progress bar, a "limited" chip, a price sparkle.
- **Boil stickers** (#4) + a subtle **corner frame** overlay across all scenes for cohesion.
- Pull real **salepage assets** (logos, badges, screenshots) in as elements before generating new ones.

**Render-safe only (seek-based renderer):** animate via **`strokeDashoffset` draw** + `pop`/`scale`/`stagger`
entrances + boil. **Do NOT drive numbers with a JS `textContent` counter** (`onUpdate` writes don't survive
the seek-render — the value renders frozen). To show a count-up, pre-bake the frames or reveal a static final
number with a pop; keep the *bar* animating via `scaleX`/`strokeDashoffset`, not the digits.
