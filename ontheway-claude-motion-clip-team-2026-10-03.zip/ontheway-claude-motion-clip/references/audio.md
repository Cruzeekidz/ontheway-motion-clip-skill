# Audio — BGM + SFX (free library + ffmpeg mix)

The ad-specific sound layer: a quiet music bed under the VO + a few sound effects punched onto the
key beats. The VO is the spine (already in the render); this adds music + SFX on top.

> The `hyperframes bgm` (Lyria) command may be **absent in the installed CLI** (`Unknown command bgm`).
> When it is, fall back to the free-library approach below.

## Golden rules
- **⛔ Customer picks SFX/BGM/voice by ear — you can't hear them. THIS IS A HARD GATE (Pipeline step 8).**
  Before the final mix you **MUST** build a **playable `sound_picker.html`** with `<audio controls>` for
  **every BGM candidate AND every per-beat SFX candidate** (+ a "ไม่ใส่" option) **AND 3 voiceover versions**
  — `open` it, and **STOP and wait for the customer's pick**. **Never silently self-select the music/SFX/voice
  and jump to the mix.** This is the single most commonly skipped step — it is listed as a Hard Rule in SKILL.md.
  You may pre-select sensible defaults *inside* the picker UI, but the customer must still confirm/change them.
  Picking by "category + duration" alone reliably misses. Ship a standalone `sound_picker.html` — do NOT rely
  on the storyboard's preliminary SFX previews as the final picker.
- **Always offer 3 VOICEOVER versions in that SAME picker.** Whenever the ad has narration, generate the VO in
  **3 distinct voices** that fit the brief (e.g. 3 female timbres for a luxe piece; or mix male/female) using
  the same script + delivery direction, and put all three as `<audio controls>` in the sound picker **next to
  the music** — the customer picks the voice and the track in one step. Build/time the render against a sensible
  default voice; if the customer picks a different one, **re-render with it** (re-transcribe timing — voices
  differ in length). Make one of the three the voice you already built with, so picking it needs no re-render.
- **BGM volume is FIXED at `0.20` (20%).** Do not expose volume as a customer choice. Fade in 0.6s, out 1.0s.
- **Keep the audio mix as a separate file** (`out_audio.mp4`) until approved — never overwrite the
  clean `out.mp4`.
- SFX skew **Western** on most free libraries. If the client wants **Thai-familiar / meme SFX** (the
  CapCut/TikTok-style เด้ง/ปิ๊ง/ตึ่งโป๊ะ stings), expect them to **supply their own pack** — drop those
  files into `source_material/` (or `sfx/`) and place them the same way.

## ⭐ Bundled Thai-familiar SFX pack (PREFER THIS) — `assets/soundfxs/`

The skill ships a curated pack of **Thai-creator-familiar / meme SFX** in `assets/soundfxs/` (the
CapCut/TikTok-style stings Thai audiences recognize). **For Thai content, reach for this pack FIRST**
— it lands far better than the Western-skewed free libraries below. Filenames carry their duration
(`name_<sec>s.mp3`) so you can budget at a glance. Catalog + typical use:

| file | what it is | use on |
|---|---|---|
| `vine-boom-sound-like-explode_1.3s` | Vine Boom (deep bass hit) | กระแทก/ปัง, slam, dramatic punch |
| `people-aww-disappoint_3.0s` | crowd "awww" | sympathy / sad beat / มุกแป้ก (trim) |
| `correct-dingdongdingdong-short_1.3s` | game "correct!" chime | right answer / price = คุ้ม / value reveal |
| `anime-wow_4.2s` | anime "wow" | surprise / delight / ของอร่อย (trim ~1.3s) |
| `kids-saying-yay_8.2s` | kids cheer "เย้" | celebration / payoff / CTA (trim ~1.8s) |
| `ding-microwave_3.0s` | microwave ding | done / พร้อมเสิร์ฟ / ready (trim) |
| `metal_gear_solid_spotted_1.6s` | MGS "!" alert | realization / จับได้ / peak |
| `windows-error_1.0s` | Windows error | fail / แป้ก / problem |
| `bruh_0.8s` | "bruh" meme | deadpan / ผิดหวัง |
| `duck-rubber-toy-beepbeep_1.0s` · `mac-quack-duck_1.1s` | squeak / quack | cute comedic punctuation |
| `running-effect-cartoon_2.1s` | cartoon scramble | rushing / panic (trim) |
| `mouse-click_3.1s` | mouse clicks | clicking / กดสั่ง / select |
| `iphone-message-notification_4.6s` | iMessage ding | message / ออเดอร์เข้า (trim) |

**Budget rule — keep SFX ≤ 30% of the video's duration** (sum of placed SFX lengths ≤ 0.30 × total).
This is a guardrail against SFX clutter — *try* to stay under it by default; only exceed it if the user
explicitly asks for more. Long files: **trim to the useful sting** (e.g. `kids-saying-yay` → ~1.8s) so a
few placements stay well within budget. Pick by the filename's meaning + duration; place on the beat.

**Spacing rule — SPREAD SFX across the whole timeline; never cluster.** Aim for **~1 SFX per scene**,
keep a **minimum gap (~3–4s)** between any two, and cover the WHOLE video — don't pile several into the
opening seconds and leave the middle silent. Map one sound to each scene's key beat and space them evenly.

**Level rule — BALANCE then keep them soft.** Free/meme SFX have wildly different inherent loudness (a
Vine-boom peaks near 0 dB; an anime "wow" can sit ~7 dB lower). If you place them at the same `volume`,
the loud ones blast and the quiet ones vanish ("ไม่ครบ"). So **normalize each to a consistent mix level**
(measure with `volumedetect`; target each SFX to land ~6–8 dB above the 20% BGM, e.g. mix mean ≈ −15 dB)
rather than a flat volume. Then keep that level **soft** — SFX punctuate, they don't dominate the VO.

**No abrupt cut ("ขาดตอน").** When you trim a long SFX, add a short `afade=t=out` at the end (≈0.2–0.4s)
so it decays naturally instead of getting chopped mid-sound.

(Users may add their own files to this pack; treat any `assets/soundfxs/*.mp3` as available.)

## Sourcing — Mixkit (free, commercial OK, no key/login, no attribution) — Western-leaning fallback
- **BGM:** `https://mixkit.co/free-stock-music/<genre>/` — genres incl. `funk` `disco` `children`
  `bossa-nova` `cinematic` `corporate-music` `chiptune` … Pick a genre matching the ad's tone
  (funk/disco = upbeat fun; children = playful/quirky; cinematic = serious). Direct file URLs:
  ```bash
  curl -s -A "Mozilla/5.0" "https://mixkit.co/free-stock-music/funk/" \
    | grep -oE 'https://assets\.mixkit\.co/music/[0-9]+/[0-9]+\.mp3' | sort -u
  ```
- **SFX:** `https://mixkit.co/free-sound-effects/<category>/` — `impact` `coin` `magic` `whoosh` `pop`
  `bell` `cartoon` `game` `drum` … Every item on a category page is that type. Direct URLs:
  ```bash
  curl -s -A "Mozilla/5.0" "https://mixkit.co/free-sound-effects/whoosh/" \
    | grep -oE 'https://assets\.mixkit\.co/[^"]+-preview\.mp3' | sort -u
  ```
  (Sound **names** are DB-rendered — not in the static HTML. Rely on the category + the customer's ear,
  not the filename.) Run network `curl` with the sandbox disabled.

## Place SFX on the beats
Map each SFX to the exact timeline timestamp (you already know them from the build):
slam/impact on the hit · ka-ching on the price reveal · **whoosh on every scene transition** ·
sparkle on the delight beat · pop on logo/CTA bumps.

## Mix (ffmpeg, onto the rendered mp4 — no video re-render)
VO is baked into `out.mp4`; layer BGM + SFX over it. Per the working `_mix_audio.py` pattern:
- **VO:** `[0:a]aformat=channel_layouts=stereo:sample_rates=44100,volume=1.0[vo]`
- **BGM:** `[1:a]atrim=0:<DUR>,aformat=channel_layouts=stereo:sample_rates=44100,volume=0.20,afade=t=in:st=0:d=0.6,afade=t=out:st=<DUR-1>:d=1.0[bgm]`
- **Each SFX i** (own input, reuse a file across beats by adding it as multiple inputs):
  `[i:a]atrim=0:<len>,aformat=channel_layouts=stereo:sample_rates=44100,volume=<v>,adelay=<ms>:all=1[ei]`
- **Combine:** `[vo][bgm][e0][e1]…amix=inputs=K:normalize=0:dropout_transition=0,alimiter=limit=0.95[mix]`
- **Output:** `-map 0:v -map [mix] -c:v copy -c:a aac -b:a 192k -shortest out_audio.mp4`

`normalize=0` keeps each level as set (mix won't auto-duck); `alimiter` guards clipping. Typical SFX
volumes 0.5–0.95, whoosh ~0.45. Generate the filtergraph from a small python list of
`(file, time_s, volume, trim)` rather than hand-writing it.

> Alternative (cleaner, editable, but slower to iterate): declare `<audio src data-start data-volume
> data-track-index>` nodes as **direct children of the composition root** in `index.html` and let
> hyperframes mix at render. Use when you want the audio versioned with the composition.

## Storyboard integration — use the CHOOSER TEMPLATE (don't hand-roll it)
Because the storyboard (STEP 3) is the customer-facing approval, put the **SFX/BGM chooser there**:
per scene, 2–3 candidate SFX as `<audio controls>` + a "ไม่ใช้" option; a few BGM tracks to audition.

**Always build it from `assets/audio-chooser.html`** (copy → fill rows → `open`). The template has the
required behaviours baked in so we stop forgetting them:
- **SINGLE PLAY (mandatory):** pressing play on one track PAUSES all others — never let tracks overlap
  (a chooser where two songs play at once is unusable). The template wires this on every `<audio>`.
- Copy-to-clipboard of the pick(s); simple-HTML house style; a "custom mood / ไม่ใส่เพลง" option.
Group candidates under mood headers (e.g. corporate / funk / house / cinematic) and mark one `rec`.
Download the mp3s locally (`bgm/<id>.mp3`) and reference them so it plays offline.
Volume is not a choice (fixed 20%). After the customer copies their picks back, run the ffmpeg mix.
