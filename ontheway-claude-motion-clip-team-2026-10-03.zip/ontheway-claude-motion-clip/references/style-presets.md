# Art Direction presets

Two house styles ship as presets. They are **starting points** — if the sale page has a strong
identity of its own, propose a custom direction derived from it. Always offer the choice; never
pick silently.

Both presets share Thai type: **Anakotmai** (Bold/Medium) for headlines, **Sarabun**
(Regular/SemiBold/Bold) for body. Download local `woff2` and `@font-face` with
`font-display:block` (see `workflow.md`). Don't rely on emoji fonts.

---

## Preset A — Editorial White

Magazine-clean, paper-and-ink, calm but premium. Good for trust/credibility-led messages.

```css
:root{
  --bg:#F5F1E8;     /* warm paper */
  --ink:#111111;    /* near-black text */
  --wine:#4A1018;   /* deep wine — primary accent / headlines */
  --gold:#B8965A;   /* gold accent */
  --gold-deep:#8A6A2E; /* darkened gold — passes contrast on white */
  --muted:#6B6357;
}
```

- White/paper background. Headlines in wine or ink; gold for emphasis (use `--gold-deep` for any
  gold TEXT on white so it passes WCAG; bright gold is for fills/strokes only).
- Texture: faint **notebook grid** at ~12% opacity (see techniques) + optional decorative
  **boil stickers** (washi tape / paper clip) ≤15% of the frame, no positional movement.
- Mood: editorial, hand-made, calm. Transitions: push slide / blur crossfade.

---

## Preset B — Dark Bold / Secret Reveal

Near-black, high-contrast, punchy. Gold = "the real thing / the course"; red = "myth / risk /
the thing they fear". Good for myth-busting, contrarian, pattern-interrupt angles.

```css
:root{
  --bg:#0A0A0A;     /* near-black */
  --paper:#F5F1E8;  /* cream — for chat/AI bubbles, cards */
  --ink:#F5F1E8;    /* off-white text */
  --gold:#D2A94E; --gold-deep:#B8923A; /* gold = truth / course / CTA */
  --red:#E33D33;    /* red = myth / risk / strike-through */
  --muted:#8C857A;
}
```

Signature treatments:
- **Vignette** over everything: `radial-gradient(ellipse 78% 62% at 50% 42%, rgba(0,0,0,0) 50%, rgba(0,0,0,.66) 100%)` (z above scenes).
- **Faint dot grid** texture ~5% opacity.
- **Strike-through kill**: animate a red bar `scaleX 0→1` across a myth phrase to "cross it out".
- **Risk box**: a red-bordered, slightly-tinted card holding the scary concept, with a gentle pulse.
- **Gold check rows**: circle-checkmark + line for benefit lists.
- **Scale-punch** (`back.out`) on hero reveals (the secret, the payoff phrase).
- Mood: bold, confident, a little cinematic. Transitions: scale punch + push, fast.

---

## Preset C — Dark Red / Oxblood

Deep oxblood-red, rich and a little dramatic. Same bold/punchy energy as Dark Bold but warmer —
good for urgency, "filter the fakes", framework-driven angles.

```css
#root{ background:radial-gradient(ellipse 92% 72% at 50% 36%, #3E0C12 0%, #220709 56%, #150406 100%); }
:root{
  --paper:#F6EFE3; --ink:#F6EFE3;          /* cream text / cards */
  --gold:#E8B85C; --gold2:#C99B45;          /* gold = the real thing / letters / course / CTA */
  --ember:#FF6A4D; --red:#E8473A;           /* ember/red = pain / warning / strike */
  --muted:#B08B83;                          /* muted rose-grey */
}
```

- Same vignette + faint dot grid as Dark Bold; stock footage tinted red/dark at ~16% reads great.
- Gold pops hardest on oxblood — use it for hero words, framework letters (e.g. a B/A/N/T grid),
  and the CTA. Ember (`--ember`) for the pain/strike/"ghost" beats.
- Mood: warm-dramatic, confident. Same transitions as Dark Bold (scale punch + push).

Type scale used (all presets, vertical 1080×1920):

```css
h1{font-family:"Anakotmai";font-weight:700;line-height:1.06;letter-spacing:-.5px;}
.xl{font-size:104px;} .lg{font-size:84px;} .md{font-size:66px;} .sm{font-size:52px;}
.body{font-family:"Sarabun";font-weight:600;font-size:46px;line-height:1.34;}
```

Scenes are full-frame layers (`position:absolute;inset:0`), content centered in a ~912px column.
Scene 1 visible by default; scenes 2+ start `opacity:0` on the container and are revealed by GSAP.

---

## Preset D — Scrapbook Warm (cut-paper KVs + boil + taped photos)

Cozy, warm, hand-made "scrapbook" look on a **light** cream page — the opposite of the dark presets.
Charming and lively without feeling cheap. Great for empowering / trust / "you can do this" angles,
or just to make one ad in a set look completely different. **User loves this one** — the liveliness
comes from MANY floating KVs + boil stickers + real photos turned into taped polaroids.
Canonical working example: `the_fearless_accounting/c2/` (index.html + `gen_plate.py` + `c2/kv.json`).

```css
:root{
  --paper:#F5EEDD; --ink:#3E3022; --ink2:#6B5742;   /* warm cream bg, warm dark ink text */
  --teal:#2E8B7F; --teal2:#3FBFA3;                  /* teal accent (deeper teal reads on light bg) */
  --red:#C0533B; --gold:#C39A45; --kraft:#B08A5E;   /* brick-red = risk/fear, gold = emphasis, kraft = paper */
  --cream:#FFFDF5;                                  /* polaroid / card white */
}
/* warm page: cream gradient + two soft glows */
#root{ background:
  radial-gradient(ellipse 92% 58% at 50% 16%, rgba(195,154,69,.12), transparent 60%),
  radial-gradient(ellipse 84% 56% at 50% 100%, rgba(46,139,127,.12), transparent 60%),
  linear-gradient(180deg,#F7F0E0,#EEE3CC); }
/* notebook grid ~6% + paper dots ~5% (both pointer-events:none, low z) */
.grid{background-image:linear-gradient(rgba(110,82,52,.9) 1.4px,transparent 1.4px),
      linear-gradient(90deg,rgba(110,82,52,.9) 1.4px,transparent 1.4px);background-size:56px 56px;opacity:.06;}
.vig{background:radial-gradient(ellipse 86% 74% at 50% 46%, transparent 56%, rgba(70,46,20,.20) 100%);} /* warm, gentle */
```

**The KV system (the heart of this preset) — generate MANY, keep them floating:**
- **Style = cut-paper collage.** Generate each KV with Gemini (`gen_plate.py`, `aspect:"1:1"`), style modifier:
  *"warm cut-paper collage illustration, layered torn-paper craft with paper grain and soft drop shadows
  between layers, cozy scrapbook aesthetic, warm earthy palette (cream/kraft/teal/brick-red), ONE clear
  centered subject with a strong simple silhouette, minimal props, on a PLAIN solid off-white (#F3ECDD)
  background with crisp clean edges for easy background removal, uncluttered."* (gen_plate already appends
  "no text, no logos, no watermark".)
- **One KV per scene, refresh every 1–3 slides** — lots of KVs is what makes it feel alive (user's words:
  "kv เยอะ ๆ แบบนี้ ดูไม่นิ่ง"). Literalize each beat: doubt = worried owner + "?", audit = magnifier over
  tax docs, confusion = owner with tangled-number page, payoff = owner holding a chart up, guarantee = shield+coins+check.
- **Background-remove + trim**: `rembg` (u2net, `post_process_mask=True`) → `getbbox()` crop. QA by compositing
  all cutouts onto the warm bg in one contact sheet and eyeballing edges; regenerate any with halos/holes.
- **kvIn entrance + perpetual float** — this gives the gentle drift the user loves:
  ```js
  function kvIn(sel,t){ tl.fromTo(sel,{opacity:0,scale:0.34,y:-130},{opacity:1,scale:1,y:0,duration:0.85,ease:"back.out(1.5)"},t);
    var c=2.4,r=Math.ceil((DUR-t)/c)-1; tl.to(sel,{y:-10,duration:c/2,ease:"sine.inOut",repeat:r>0?r*2+1:1,yoyo:true},t+0.9); }
  ```
  KV sits ABOVE the text; KV+text = one vertically-centered group. `.kv img{max-height:520px;width:auto;filter:drop-shadow(0 20px 34px rgba(60,40,20,.34));}`

**Real photos → taped polaroid (user loves "เอาภาพจริงมา modify"):** put the real course cover / instructor
photo in a white polaroid frame with washi tape and a slight tilt — it reads as a scrapbook clipping.
```css
.pola{position:relative;background:var(--cream);padding:14px 14px 44px;border-radius:6px;
  box-shadow:0 22px 46px rgba(60,40,20,.38);transform:rotate(-2.5deg);}
.pola img{display:block;width:100%;border-radius:2px;}
.pola .cap{position:absolute;left:0;right:0;bottom:12px;text-align:center;font-weight:700;font-size:26px;color:var(--ink2);}
.tape{position:absolute;width:140px;height:40px;background:rgba(63,191,163,.5);box-shadow:0 3px 8px rgba(0,0,0,.12);}
```
Animate it in with a small `back.out` scale+rotate.

**Boil stickers + SVG elements interspersed (user: "ใส่ elements boil stickers แทรก ดีมาก"):** sprinkle 1–3
per scene — washi tape (parallelogram), paper clip (stroke path), sparkle-star — each as `.fa`/`.fb` 2-path
variants doing the 2-frame boil (`steps(1)` yoyo, finite repeat, `data-layout-ignore`, ≤15% frame). Boil here
is ON (unlike the dark cinematic preset) because the whole look is hand-made. Plus normal SVG bits: a red
"ราคาเปิดตัว" chip, gold star row, a teal guarantee pill, the CTA pill. (Boil mechanism: techniques.md #4.)

**Layout / type (4:5, 1080×1350):** content **vertically centered** (`justify-content:center`), `gap:18px`,
`padding:0 90px`. Type a notch smaller than the dark presets: `.xl 78 / .lg 60 / .md 48 / .sm 37 / .kick 30`.
Text is warm `--ink` on cream; `--teal`/`--red`/`--gold` for accents; brand name in `--teal`.

**Motion / transitions:** scene crossfade (opacity in/out ~0.5s); grid drifts slowly (`backgroundPosition` over
DUR); glows breathe. No dark stock-video layer — the grid + boil + floating KVs carry the life. Mood: warm,
crafty, friendly, never static.

**Pipeline recap:** write `kv.json` (style + 1:1 + per-beat scenes) → `gen_plate.py kv.json img/kv` →
rembg+trim → QA sheet → copy real cover/instructor → build `index.html` (grid bg + per-scene KV/polaroid +
boil + centered text) → lint/inspect (boil overflow + entrance-tween overlaps are false positives) → render → verify.

---

## Preset E — Cinematic Photoreal (full-bleed AI plates)

Premium, moody, film-like — full-bleed **photoreal** scene backgrounds (no illustration, no boil).
Each scene is a Gemini-generated photoreal "plate" with type over its dark negative space. Great for
serious, high-stakes, emotional angles. Canonical example: `the_fearless_accounting/c1/`.

- **Plates**: `gen_plate.py` (`aspect:"3:4"`, full-bleed — NOT cutouts, no rembg), style e.g.
  *"cinematic photorealistic still, moody low-key lighting, warm key light against deep [brand-color]
  shadows, shallow DOF, film grain, premium serious mood, generous dark negative space for text."*
  One plate per scene; each scene's `.plate img` does a slow **Ken Burns** (scale 1.06→1.17). Mark the
  `.plate` `data-layout-allow-overflow` (the zoom overflows its clip box on purpose).
- **Legibility**: a per-scene `.scrim` = a central radial darken + vertical gradient, behind centered text;
  strong text-shadow on headlines.
- **Liveliness**: a faint **real video texture** overlay on top (dust → light-leak, `mix-blend-mode:screen`,
  opacity ~0.3–0.5, tiled 2 clips) + a subtle gold **corner frame** (viewfinder) across all scenes.
- **Elements**: premium SVG motion-graphics (draw-on underlines/▼drop on numbers, finance icons,
  star ratings, module row, 3-statement-doc+check row, price sparkle) — render-safe via `strokeDashoffset`
  draw + pop/stagger, NO JS counters. Real course cover used as a framed hero at the reveal.
- **Layout**: content **vertically centered** with the central scrim. Palette = derived from the salepage,
  rotated per ad across a set. Mood: cinematic, premium. Transitions: opacity crossfade between plates.

---

## Preset F — Bold Risograph "Alert" (silkscreen poster)

Loud, punchy, retro-print. A 2–3 spot-colour **risograph / silkscreen** look on cream paper: flat bold
shapes, heavy halftone + grain, deliberate ink **misregistration**. Reads as alarming / urgent — perfect
for fear/risk/"leak/fraud/danger" angles and short, fast, punchy scripts. Canonical example: `the_fearless_accounting/c3/`.

```css
:root{ --paper:#F2E9D8; --ink:#221A12; --red:#D8392C; --red2:#B82E22; --teal:#2E8B7F; --gold:#C2922F; --cream:#FFFBF0; }
/* riso surface: halftone red dots (~10%) + fine ink grain (~7%) */
.halftone{background-image:radial-gradient(circle, rgba(216,57,44,.9) 3px, transparent 3.6px);background-size:22px 22px;opacity:.10;}
.grain{background-image:radial-gradient(circle, rgba(34,26,18,.9) .7px, transparent 1px);background-size:5px 5px;opacity:.07;}
/* misregistered poster frame: an ink border + a red border offset by ~6px */
.frm.ink{border:5px solid var(--ink);} .frm.red{border:5px solid var(--red);transform:translate(6px,6px);opacity:.85;}
```

- **KVs = risograph print** style. Gen prompt modifier: *"bold risograph screen-print illustration, 2–3 flat
  spot colours (cream paper, alarm red, deep ink black, touch of teal), heavy grain + halftone, slight ink
  misregistration offset, bold flat shapes with thick outlines, retro poster, ONE centered subject, plain
  cream (#F2E9D8) bg, crisp edges, no text."* Cut out with rembg. Give cutouts a hard **offset drop-shadow**
  in red (`filter:drop-shadow(8px 10px 0 rgba(216,57,44,.28))`) to echo the misregistration.
- **Entrances are punchy, not floaty**: `kvP` = scale-from-0.5 + slight rotate `back.out(1.8)` + a small bob.
  Fast scene crossfades (~0.36s). Big condensed Anakotmai type. Red = danger words, gold = money, teal = the fix.
- **Riso props**: a bordered rotated **"100%?" stamp**, a red **draw-on down-arrow**, real cover in a card with
  an **ink border + solid red offset shadow** (`box-shadow:10px 12px 0 var(--red)`), a red CTA with an ink shadow.
- NO boil stickers, NO video texture — the halftone + grain + bold flats carry it. Mood: loud, alarming, retro-print.

---

## Deriving a custom direction

When proposing a custom look from a sale page:
1. Pull the page's actual palette (background, primary, accent) and a real headline font vibe.
2. Keep the house DNA: text-led, no eyebrows, big type, real assets, subtle motion.
3. Define the same token set (`--bg --ink --accent --accent2 --muted`) + the type scale above.
4. Pick ONE primary transition + 1–2 accents (see `hyperframes-animation`), matched to the mood.
