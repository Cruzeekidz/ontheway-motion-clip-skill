# Animation vocabulary

A small set of reusable GSAP helpers covers ~all ad motion. Build the timeline `paused`, register
`window.__timelines["main"] = tl`, and drive everything from one timeline. All times are absolute
seconds on the narration spine.

```js
window.__timelines = window.__timelines || {};
var tl = gsap.timeline({ paused: true });
var $ = function (s) { return document.querySelector(s); };

// ENTER — primary entrance: stagger .ln children in from the right
function enter(id, t) {
  var sc = $("#" + id);
  tl.set(sc, { opacity: 1 }, t);
  tl.from(sc.querySelectorAll(".ln"), { x: 96, opacity: 0, duration: 0.5, stagger: 0.12, ease: "power3.out" }, t + 0.02);
}

// PUNCH — hero reveal: scale-up with overshoot (the secret / the payoff)
function punch(id, t) {
  var sc = $("#" + id);
  tl.set(sc, { opacity: 1 }, t);
  tl.from(sc.querySelectorAll(".ln"), { scale: 0.55, opacity: 0, duration: 0.55, stagger: 0.13, ease: "back.out(1.7)" }, t + 0.02);
}

// LEAVE — the transition (= the exit). New scene's enter()/punch() fires ~0.05s later.
function leave(id, t) {
  var sc = $("#" + id);
  tl.to(sc.querySelector(".sc"), { x: -120, opacity: 0, duration: 0.42, ease: "power3.in" }, t);
  tl.set(sc, { opacity: 0 }, t + 0.42);
}

// STRIKE — red bar crosses out a myth phrase (.bar inside .kill)
function strike(id, t) {
  tl.to($("#" + id).querySelectorAll(".bar"), { scaleX: 1, duration: 0.5, stagger: 0.14, ease: "power2.inOut" }, t);
}

// POPIMG — image pops in (scale + rise)
function popImg(sel, t) {
  tl.from(sel, { scale: 0.9, opacity: 0, y: 36, duration: 0.6, ease: "power3.out" }, t);
}

// KB — slow Ken Burns zoom; keeps an image scene alive. Start AFTER its entrance finishes.
function kb(sel, t, dur) {
  tl.fromTo(sel, { scale: 1.0 }, { scale: 1.08, duration: dur, ease: "sine.inOut" }, t);
}

// PULSE — gentle emphasis that returns to rest (risk box, CTA button). count = finite repeats.
function pulse(sel, t, count) {
  tl.to(sel, { scale: 1.04, duration: 0.7, ease: "sine.inOut", repeat: count, yoyo: true }, t);
}

// FLOATGRP — perpetual gentle drift on a whole scene group so a TEXT-ONLY scene never sits dead.
// Put it on the .sc wrapper (NOT the entrancing .ln children, or it fights their from-tweens). Finite.
function floatGrp(sel, t, endT) {
  var c = 2.6, r = Math.ceil((endT - t) / c) - 1;
  tl.to(sel, { y: "-=14", duration: c / 2, ease: "sine.inOut", repeat: r > 0 ? r * 2 + 1 : 1, yoyo: true }, t);
}

// GLINT — quick brightness shimmer across a gold hero word right after it lands. Cheap "it's alive" accent.
function glint(sel, t) {
  tl.fromTo(sel, { filter: "brightness(1)" }, { filter: "brightness(1.72)", duration: 0.17, yoyo: true, repeat: 1, ease: "sine.inOut" }, t);
}

// TILTIN — 3D flip-up entrance (needs `perspective:1100px` on .scene). More alive than a flat fade.
function tiltIn(sel, t) {
  tl.from(sel, { y: 78, opacity: 0, rotationX: -55, transformOrigin: "50% 100%", duration: 0.62, ease: "power3.out" }, t);
}
```

**Semantic / directional entrances — let the motion MEAN something.** Don't fade every line the same
way. When two lines are *in tension* (a contrast, a mismatch, a "this vs that"), enter them from
**opposite sides** so the motion itself carries the idea — e.g. for "พูด**ไม่ตรงกัน**" slide line A in
from the left and the punch word in from the right; they literally don't line up:
```js
tl.from("#s2a", { x:-210, opacity:0, duration:0.6, ease:"power3.out" }, t);
tl.from("#s2b", { x: 220, opacity:0, duration:0.66, ease:"back.out(1.5)" }, t + 1.7); // opposite dir = "mismatch"
glint("#s2b", t + 2.3);
```
Other cheap, meaningful variants: a kicker that expands its `letter-spacing` open (`from {letterSpacing:"0.55em"}`)
for an "oracle reveal"; `scale`-punch + `glint` on the one word that matters; `tiltIn` for a confident drop.

Mark up scenes so the helpers work: each animatable block gets class `.ln`; the inner column is
`.sc`; strike phrases wrap text in `.kill` containing a `.bar`. Example scene:

```html
<div class="scene" id="s1">
  <div class="sc" data-layout-allow-overflow>
    <h1 class="lg ln">ขายงานองค์กรใหญ่</h1>
    <h1 class="lg ln"><span class="kill">ถ้าไม่มีเส้นสาย<span class="bar"></span></span></h1>
  </div>
</div>
```

## Rules (non-negotiable)

- **Every scene has an entrance.** Nothing pops fully-formed onto screen.
- **No static scene — keep every frame alive (the user is strict about this).** A scene that plays
  its entrance once and then sits frozen until `leave()` reads dead — worst on the early **text-only**
  scenes (hook/opener), which often have no image to Ken Burns. The background breathing (aura/stars/grid
  drift) is NOT enough; the **foreground** must keep moving too. Two levers, use BOTH:
  (1) **continuous low-amplitude motion** on every scene — an image scene gets `kb`; a text-only scene
  gets `floatGrp("#sN .sc", start, end)` (a ~±14px sine drift on the group);
  (2) **vary the entrance per scene** — don't reuse one flat `enter()` everywhere; rotate `tiltIn`,
  opposite-side slides (semantic), `punch`+`glint`, letter-spacing opens. Verify by scrubbing each
  scene: if any **>1.5s** stretch shows zero foreground movement, add a drift or a beat. (`floatGrp`
  goes on the `.sc` wrapper so it never collides with the children's entrance from-tweens; needs
  `perspective:1100px` on `.scene` only for `tiltIn`.)
- **No exit animations except the final scene.** `leave()` (the push-out) IS the transition; the
  outgoing content must be fully visible when it fires. Only the last scene may fade its own content out.
- **No `repeat: -1`.** For any loop (typing dots, boil, pulse) compute `Math.ceil(span / cycle) - 1`.
- **Sequence, don't overlap, on the same property of the same element.** e.g. `popImg` (sets scale→1)
  then `kb` (scale 1→1.08) on the same image: start `kb` after the pop finishes. Put ambient motion
  on a wrapper, entrance on the inner element, if they'd otherwise collide.
- **`gsap.from`/`fromTo` use immediateRender** — a late-starting `from` holds the element in its
  from-state from t=0. That's fine because the scene container is `opacity:0` until its scene time;
  it keeps elements hidden until their cue. Don't also pre-`set` opacity:0 before a `from{opacity:0}`
  (that animates 0→0 = stays invisible) — use `fromTo` if you must pre-hide.

## Picking transitions

Match the transition to the content's emotion, not just the look. Keep ONE primary (60–70% of
cuts) + 1–2 accents. Calm → blur/crossfade; medium/editorial → push slide; bold/promo → scale
punch + fast push. Full catalog + energy/mood tables live in the `hyperframes-animation` skill.
