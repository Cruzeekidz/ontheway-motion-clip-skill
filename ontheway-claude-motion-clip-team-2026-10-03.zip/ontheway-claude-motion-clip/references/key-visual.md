# AI key visual (opening hero)

An optional but high-impact opener: a fun, slightly-surreal **key visual** generated with AI,
background-removed to a transparent PNG, floating on the first slide. It must appear **in the very
first frame** and stay for **no more than ~20% of the clip** (it's the hook, then the ad moves on).

Concept: literalize the pain/promise with a charming, mildly surreal scene. e.g. for a B2B selling
ad → a dejected businessman stranded on an island made of stacked paper documents, with a laptop
and phone beside him. Playful, a little funny, simple background.

## KV is mandatory — and whose face you may generate

- **Every ad must have a KV, and text-only never ships.** A slide that is pure type — *even over a pretty
  background* — is not a valid output ("ตัวอักษรล้วน แม้จะมี background สวย ไม่ควรเอาไปใช้จริง"). A usable KV is
  a **hero subject floating in the foreground** (person / product / object), cut out and composited with depth.
- **Object-KV is the safe fallback.** When there's no real photo of a person yet, use an **object that signals
  the payoff** (e.g. money waiting, a trophy, the product box): generate a *minimal object on a plain bg* →
  remove-bg → composite. Make a matching series in one style.
- **Reference-Person rule — never AI-generate the brand's real owner/instructor's face.** Generic/incidental
  people and objects may be AI-generated; the actual product owner or teacher must be a **real supplied photo**.
  If you don't have it, ask for a Reference Person photo — don't fabricate their likeness. (Templates ship an
  unbranded `img/avatar.jpg` placeholder for exactly this reason.)

## Generate 4 styles EVERY time

Always produce **four** variations of the same concept, show all four, let the user pick one, and
keep the rest as swappable backups. The four styles:

1. **3D Pixar** — playful 3D character render, soft cinematic lighting, warm rounded shapes.
2. **Flat editorial** — modern flat vector, limited bold palette, geometric and minimal.
3. **Clay diorama** — cute isometric clay/toy miniature, matte materials, whimsical.
4. **Photorealistic duotone (selective color)** — realistic photo in high-contrast B&W EXCEPT one
   object rendered in a single bold accent color (the only color in the frame). Ties beautifully to
   an accent-driven theme (e.g. gold) and the plain studio background cuts out cleanest.

Use Gemini's image model via the saved key (see the `gemini-api` skill; key at
`~/.config/google-genai/.env`, never print it). Request a transparent-friendly
composition: **1:1 (square)** — NOT vertical. A tall 9:16 key visual eats the entire vertical space
of an already-vertical video, so once it's cut out and placed there is no room left for the headline;
a square cutout sits compactly with text above/below. Subject centered with generous margin, on a
**plain SIMPLE solid background** with crisp edges (this is what makes background removal clean).
Always append: "no text, no logos, no watermark".

**Keep the subject CLEAN and simple — one clear hero with a strong silhouette + minimal props.**
Avoid busy, cluttered, intricate scenes (dense org charts, crowds, dozens of tiny boxes, thin
connector lines, fine detail). Detail-heavy images do NOT survive background removal — rembg leaves
ragged holes and halos between fine elements — and they read as visual mush at small size. If the
concept is inherently busy, **simplify it to its essence** (one figure + a few suggestive shapes,
not a full 50-node diagram). A clean subject on a plain background is the whole game for a good cutout.

```python
# img generation — generateContent with IMAGE modality + aspect ratio
body = {
  "contents": [{"parts": [{"text": prompt}]}],
  "generationConfig": {"responseModalities": ["IMAGE"], "imageConfig": {"aspectRatio": "1:1"}},
}
# POST https://generativelanguage.googleapis.com/v1beta/models/gemini-3-pro-image:generateContent
# header x-goog-api-key: $GEMINI_API_KEY ; response part.inlineData.data is base64 image bytes
```
**Model preference (user):** prefer **Nano Banana 2** over Pro for key visuals (faster/cheaper, and
the user likes its look). In this key's catalog "Nano Banana 2" maps to the gen-2 Flash image model
**`gemini-3.1-flash-image`** (Nano Banana 1 = `gemini-2.5-flash-image`; Nano Banana **Pro** =
`gemini-3-pro-image` / alias `nano-banana-pro-preview` — keep as the higher-quality fallback). There
is no literal `nano-banana-2` id — model names drift, so verify the current one with the catalog list
in the `gemini-api` skill and pick the latest non-Pro Nano Banana. Override per run with the
`KV_MODEL` env var (the script reads it); default to Nano Banana 2.

A ready generator lives in the project as `gen_kv.py` (4 styles, runs all or a subset:
`python3.11 gen_kv.py gemini-3-pro-image kv4_duotone`). Each style prompt = a shared CONCEPT string
+ a style modifier.

## Remove the background (intelligent, local)

Use **rembg** (U²-Net segmentation) — intelligent, free, local, outputs a transparent PNG.

Install (note: as of now Python 3.14 has no `onnxruntime` wheel — use **python3.11**):
```bash
python3.11 -m pip install --user "rembg[cli]" onnxruntime pillow
```
Run (first call downloads the ~176MB model to `~/.u2net/`):
```python
from rembg import remove, new_session
from PIL import Image
out = remove(Image.open("img/kv/kv4.png"), session=new_session("u2net"), post_process_mask=True)
out.save("img/kv/kv4_cutout.png")
```
(remove.bg / Photoroom APIs are fine alternatives if a key is available and you want razor edges.)

## QA the cutout — and RETRY if it's messy

**Always composite the cutout onto the target background (the video's dark bg) and look at it.**
```python
from PIL import Image
cut = Image.open("img/kv/kv4_cutout.png").convert("RGBA")
bg  = Image.new("RGBA", cut.size, (10,10,10,255))  # the video bg color
bg.alpha_composite(cut); bg.convert("RGB").save("img/kv/_preview_on_dark.png")
```
If it looks wrong — leftover background patches (because the generated background wasn't clean to
begin with), a grey/white halo, or chunks of the subject missing — **do not settle**:

1. **Regenerate that ONE image only** (same style key), steering the prompt toward an even simpler,
   flatter, single-color background and cleaner subject separation.
2. Re-run rembg on the new image.
3. Repeat until the cutout looks clean on the target background.

Most cutout problems trace back to a busy/gradient generated background, not to rembg — fixing the
source image is faster than fighting the matte.

## Place it in the first slide — cute zoom-in opening

The opening beat is a small staged sequence, NOT a static first frame:

1. **Frame 0 = empty** — only the background video runs. No key visual, no text yet. A clean breath.
2. **Key visual zooms in (cute), from the top** — starts ~0.3s: `fromTo` from `{opacity:0,
   scale:0.3, y:-140}` to `{opacity:1, scale:1.0, y:0}` over ~0.9s with `ease:"back.out(1.5)"`
   (the overshoot gives the playful bounce). It grows to its established "right" size.
3. **Then the text comes up** — delay the scene's `enter()` to ~1.2s so the headline staggers in
   *after* the key visual has landed.
4. After it settles, a gentle floating bob (`y` yoyo, finite repeat) keeps it alive.

Other rules:
- It's a transparent cutout: **no card frame** — drop the border/shadow/radius and add a soft
  `filter: drop-shadow(0 22px 44px rgba(0,0,0,.65))` so it sits on the background.
- Keep it on screen **≤20% of the duration**; let the opening scene's transition carry it off.
- Size it big — roughly **80% of the frame width** (trim the cutout's transparent padding first,
  e.g. `Image.getbbox()` + crop, so it fills cleanly at that width).
- Place the key visual **above** the headline, but treat the **KV + text as ONE group that is
  vertically centered** in the frame — do NOT pin the key visual to the top edge. Downsize the
  headline a notch if needed. (See the global vertical-centering rule in SKILL.md.)

## Spread key visuals across the clip — aim for one on (nearly) EVERY slide

A key visual doesn't live only on the first slide. **The user's rule is emphatic: "อย่างน้อยต้องมี kv" —
aim for a KV on nearly every slide, and refresh a NEW KV every 1–3 scenes.** Many KVs + a slight
continuous float is exactly what makes a text-led ad read as *alive / not static* (his most-praised move).
This is the primary limb of the **"No bare slide"** hard rule in SKILL.md.

- **One (fresh) KV per beat — pull from the salepage first.** Download the salepage's whole image set up
  front (cover, screenshots, product shots) and reuse them as KVs/elements before generating anything.
  Then literalize each beat: the pain (a figure buried in paperwork), a metaphor (a magnifier filtering
  tiny people), a named concept (a cute GHOST for a "ghost lead"), a payoff (a figure celebrating). A
  screenshot, a drawn chart, or an instructor portrait all count as the slide's KV too.
- **Character / mascot concepts are scene-stealers.** A cute ghost, a mascot, an expressive figure reads
  instantly and is the most memorable — lean into them wherever the script names something concrete.
- **Same recipe per KV:** 1:1 generation → clean single subject → bg-removed → on its scene it `kvIn`-zooms
  in (cute, from above) + a **gentle perpetual float**, with the scene's text following. KV + text = one
  vertically-centered group. Decorate with **boil stickers**.
- **Vary the concept per scene, keep ONE art style across all of them** (e.g. all 3D Pixar) for cohesion
  and reliably clean cuts.
- **When a beat genuinely has no literal image** (a definition, a pure framework line) — do NOT drop to a
  bare slide. Give it a **faint stock-video background** (`techniques.md #2`, 10–20%) + **animated vector
  elements** (SVG accents, underline wipes, a rule, boil stickers) so it stays textured and moving.
  "Let it breathe" = clean **+ textured + in motion**, never empty. If a slide feels **โล่ง or too
  text-heavy, add MORE elements** (salepage assets → SVG → boil stickers).
- The opener KV still uses the empty→zoom-in→text beat above; mid-clip KVs simply zoom in as their scene
  enters.
