# Technical Directions (composition + motion + transition — style-agnostic)

A **technical direction (TD)** is the *mechanic* of an ad: **where things sit** (composition/layout),
**how they enter / move / leave** (animation), and **how scenes connect** (transition). It says **nothing**
about how it looks. A TD is the reusable skeleton; you skin it.

```
A video = Technical Direction  ×  Visual Style  ×  Palette
          (this file)             (style-presets.md /   (a swappable
           the mechanic            templates.md — the    parameter)
                                   look: scrapbook /
                                   serif / neon / photo…)
```

**Why this layer exists (user's rule):** *"อย่าจดเป็น style — จดเป็น technical direction."* Example: the
scrapbook ad's real reusable idea is **"a KV sits in the CENTRE of the frame while the copy keeps moving
around it"** — the *scrapbook* look is incidental. That same mechanic works with a yellow-paper KV today or
a photoreal KV tomorrow. So we record the **mechanic** here, and treat *scrapbook / serif / neon* as
interchangeable skins (`style-presets.md`) and colour as a parameter. **Don't add a new "style" as if it
were a direction** — ask "what's the composition + motion, stripped of the look?" and record THAT.

How to use: pick a **TD** for the mechanic → pick a **visual style** (a preset or a template's look) to skin
it → pick a **palette**. The `assets/templates/` builds are concrete `TD × style` instances you can copy;
the "instances" line on each TD points you at working code.

> All TDs still obey the SKILL.md hard rules — **no dead air, no static frame, no bare slide** (KV → else
> faint stock-video bg → always moving vectors). A TD is *how* things move, not permission to sit still.

---

## Whole-video directions (pick ONE as the spine of the ad)

### TD1 — Centered KV, copy in continuous motion  ★ the default OntheWay ad
**Composition:** a single **key visual anchored in the centre** of the frame; the scene's copy stacks
above/below it, and **KV + copy are treated as ONE vertically-centred group** (never pin the KV to the top).
A fresh KV per beat, refreshed every 1–3 scenes.
**Motion:** KV does a cute **zoom-in** (`fromTo {opacity:0,scale:0.34,y:-130}→{…scale:1}`, `back.out(1.5)`)
then a **perpetual gentle float** (`y` yoyo, finite repeat). Copy **enters staggered per line**
(`from x:96 / y:40`, `stagger ~0.12`) and the whole group keeps a **low-amplitude drift** (`floatGrp`,
±10–14px) so nothing is ever frozen — this "everything keeps moving a little" IS the direction. Boil
stickers + small vectors sprinkled.
**Transition:** slide-out / crossfade between scenes (`.sc → x:-130, opacity:0`).
**Best for:** most VO-led course/product ads — warm, human, lively. **Emotion via skin:** playful (halftone),
premium (serif), cozy (scrapbook), fun (candy).
**Skin it with:** any style. **Instances:** `T2-warm-halftone-poster`, `T3-dark-serif-luxe`,
`T5-y2k-neon-candy`, Preset D scrapbook (`the_fearless_accounting/c2`), V1/V2 builds.

### TD2 — Full-bleed plate, hard-cut captions
**Composition:** each scene is a **full-frame image** (no card, no inset — the picture IS the frame); a short
caption sits over its negative space; optional one glowing accent bar.
**Motion:** **Ken-Burns punch** on every plate (`scale 1.14→1.0` `power3.out`, then slow drift); caption
**scale-punches** in (`back.out(2)`) + optional micro-shake; NO floating cutout.
**Transition:** **hard cuts** (`steps(1)`, ~0.15s) — cut to the beat, trailer-style.
**Best for:** intense / cinematic / hype / testimonial-photo beats. **Emotion via skin:** athletic, luxe,
dramatic. **Skin it with:** cinematic photoreal, mono-grade, etc. **Instances:** `T6-cinematic-bold-type`
(d7), Preset E cinematic (`the_fearless_accounting/c1`).

### TD3 — Viewfinder index + cue-synced wipes
**Composition:** light framing furniture — a thin **inner frame edge + corner ticks (viewfinder)** and a
**scene counter `NN / TOTAL`**; copy is **present from the scene start** (not staggered in), and framed proof
uses a hard offset shadow.
**Motion:** the reveal is a **wipe on the accent, synced to the VO word** — an **underline bar** or a
**strike** `scaleX 0→1` lands exactly on the spoken cue; subtle Ken-Burns on framed images; gentle group drift.
**Transition:** quick slide + opacity.
**Best for:** modern / editorial / systematic / considered-purchase. **Skin it with:** minimal, mono, any
clean look. **Instances:** `T4-minimal-editorial-index` (V3).

### TD4 — UI / HUD sequential reveal
**Composition:** the "product" is **drawn as an interface** (corner-bracket frames, checklist rows, tag grid,
progress bar) — schematic, not photographic; a cursor may be present.
**Motion:** elements **reveal in sequence** — frame scale-in (`back.out`), **checklist tick-ins** (stagger),
a **progress bar fill** (`scaleX`), a **letter-spacing collapse** on the logo, ending in a **cursor fly-in +
click** (scale-pulse + shadow flash). Smooth `power` fades, never janky.
**Render-safe:** animate the **bar** with `scaleX`; **do NOT** drive a % with a JS `textContent` counter
(freezes on seek-render — reveal the final number with a pop). See `techniques.md #7`.
**Best for:** tech / SaaS / app / dev-tool / method-as-a-system. **Instances:** `T7-cool-tech-neon` (d8).

### TD5 — Character-carried arc
**Composition:** one **consistent character/mascot** (from a single reference sheet) recurs across a
multi-scene arc; a big reactive graphic backdrop; boil stickers.
**Motion:** the character reappears per scene with an expression matching the beat; punchy pops; a spun
oversized backdrop element (sized ≥3× frame so its edges never peek in).
**Transition:** fast punchy cuts/slides.
**Best for:** comedic / sitcom / mascot-brand / appetite. **Instances:** `T1-sitcom-pop` (d1).

### TD6 — Split-screen compare
**Composition:** the frame is **divided into two synced halves** — before/after, timer/result, price-vs-price;
each half animates in from its own side (opposite directions = "mismatch"), a **strike** crosses the
losing/old side.
**Motion:** two-part entrance (`#a x:-210`, `#b x:+220 back.out` offset in time); strike `scaleX` on cue.
**Best for:** comparison / "them vs us" / cost-cut / transformation beats. **Instances:** concept-level
(used as a beat inside several ads; no dedicated template yet).

---

## Beat-level directions (drop INTO a scene of any whole-video TD)

These are mechanics for a single scene/beat — compose them inside TD1–TD6.

- **B1 — Stat-hero pop:** an oversized number/stat is the scene hero — **scale-pop** (`back.out`) + **glint**
  (brightness flash) + **pulse**; tiny labels around it. (Used everywhere: "8 คลิป", "ROAS 2.5–4".)
- **B2 — Draw-on diagram:** nodes **pop** + connectors **line-draw** (`strokeDashoffset 100→0`) in narration
  order; optional key-node pulse. Render-safe, no counters. (`techniques.md #5`)
- **B3 — Chat / DM re-enactment:** user bubble → **typing dots bob** → reply bubble **pops** in
  (`back.out`); for AI-helper / testimonial / DM proof. (`techniques.md #6`)
- **B4 — Price / CTA reveal:** strike old price → **giant price scale-pops** in (`back.out`) + glint + pulse;
  deadline + brand follow; final scene is the only one allowed an exit fade.
- **B5 — Proof-shot reveal:** a real screenshot/results image **pops** into a framed card (hard offset shadow
  or soft premium shadow per skin) + slow Ken-Burns; the number beside it does B1.

---

## Deriving / adding a new technical direction
When you spot a fresh mechanic in a build, **strip the look off it** and ask three questions, then add a row:
1. **Composition** — where do KV / copy / furniture sit? one anchor, full-bleed, split, indexed, UI?
2. **Motion** — how does each part enter, keep moving, and leave? (name the eases; keep continuous motion)
3. **Transition** — how do scenes join? (crossfade / slide / hard cut / wipe)
If two builds share all three, they are the **same TD in different skins** — don't duplicate; add the new
build to that TD's "instances" line. Only add a new TD when the *mechanic* is genuinely different, and keep
it render-safe (`strokeDashoffset`/`scaleX`/pop/stagger; no JS `textContent` counters).
