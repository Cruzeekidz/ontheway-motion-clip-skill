# Video Templates

A **template** is a complete, reusable VIDEO blueprint — distinct from the art-direction *presets*
(`style-presets.md`, which are only palette/treatment). A template bundles the whole package: art
direction **+ scene structure + KV method + animation + audio recipe + format** — a known-good combination
you can **offer the customer as a pick** ("ทำสไตล์ Template 1 ไหม?") or **grab to build the next ad fast**.

## A template is a TECHNIQUE, not a colour (read this first)
Each template captures the **technical + emotional DNA** — the *image style*, the *KV/image-generation
style*, the *type treatment*, and the *animation/motion style* — because those are what create a **different
feeling**. **Colour is a parameter, not the identity.** Every `TEMPLATE.md` ships an *example* palette but
frames it as a swappable starting hue with clearly-named ROLES (base / ink / accent …); every
`index.reference.html` is **UNBRANDED** (placeholder `[BRAND]` / `[PRODUCT]` / bracketed copy, generic
`img/*` and font names) so it drops onto **any brand**. When you reuse one, the swap list always starts with
*unbrand* + *retoken palette*, and tells you the **signature you must not lose** (the treatment/motion that
makes the emotion). Pick a template by the **emotion you want**, then paint it in the brand's colours.

Each template lives in `assets/templates/<id>/`:
- `index.reference.html` — the actual reference build (copy it, then swap the brand/KVs/copy).
- `TEMPLATE.md` — the full recipe + when-to-use + the swap checklist.
- `poster.png`, `scene-flow.png` — a hero frame + a 6-thumb scene strip (show these when offering it).

## How to use templates
- **Offering to the customer (STEP 0 / concept stage):** when the brief fits a template's tone, show its
  `poster.png` / `scene-flow.png` and offer it as one of the art-direction options. The customer can pick a
  template or a fresh direction.
- **Reusing to build:** copy the template's `index.reference.html` into the new project, then follow its
  swap list (brand → character sheet → product KVs → copy/VO → palette → SFX/BGM). Keep structure/animation.
- **Diversity still applies:** across a *set* of ads for one product, vary templates/treatments — don't ship
  the same template twice in a row (see the diversity rule in SKILL.md).
- **Liveliness / "no bare slide" always applies (SKILL.md hard rules).** Whatever template you start from,
  the final build must obey: **every scene keeps moving** (no static frame), **text on screen at all times**
  (no dead air), and **every scene carries visual substance** — a KV (aim for one on nearly every slide,
  refresh every 1–3 scenes), else a faint stock-video bg (10–20%), **plus moving vector elements** so no
  slide is โล่ง/bare. A template's reference build shows the treatment; you still add KVs/stock-bg/vectors
  per beat when you fill it. If a scene ends up text-only on flat colour, it's a defect — fix it.

## Catalog
Every row has a full recipe + unbranded reference build + poster in `assets/templates/<id>/`. **Emotion**
is the picker axis; the colours shown are just the example hues (swap freely).

| id | name | emotion / best for | signature technique (keep this) | format |
|----|------|--------------------|---------------------------------|--------|
| **T1** | **Sitcom Pop** | playful, comedic, appetite — food / café / retail / delivery / mass promos | rotating saturated bgs + sunburst, **one 2×2 character sheet** carried across a 6-scene sitcom arc, boil stickers | 4:5 |
| **T2** | **Warm Halftone Poster** | playful, energetic, affordable, handmade — mass / self-serve / promo / value | **halftone screen + hard-offset "misregistration" shadow** on type & cards + boil stickers + chunky display | 4:5 |
| **T3** | **Dark Serif Luxe** | premium, trust, high-ticket, restrained — B2B / expertise / finance / luxury | **dark stage + ONE metallic accent + serif display + thin rules + glint** on numbers, framed assets, no stickers | 4:5 |
| **T4** | **Minimal Editorial Index** | modern, credible, calm, design-forward — SME / service / portfolio / considered | **light neutral + faint grid + viewfinder ticks + `NN/TOTAL` counter + single-accent WIPE reveals**, hard-offset frames | 4:5 |
| **T5** | **Y2K Neon Candy** | fun, impulse, youthful — e-commerce / fashion / snacks / flash-sale / Gen-Z | **torn-paper photo cards + double stacked hard-shadow rounded type** + halftone + scattered stars + stop-motion jitter | 4:5 |
| **T6** | **Cinematic Bold Type** | intense, athletic, premium-gritty — fitness / sport / streetwear / auto / hype | **full-bleed grayscale-plus-accent-tint photo plates + condensed-caps captions + punch-zoom hard cuts** + glow bar | 4:5 |
| **T7** | **Cool Tech Neon Mono** | techy, precise, systematic — SaaS / app / dev-tool / fintech / crypto / AI | **mono UI + blueprint grid + terminal `> LABEL.EXE` labels + corner-bracket frames + cursor-click CTA finish** | 4:5 |

All share the reusable **6-scene VO-driven course/product arc** (hook → product → benefit/speed → authority+proof
→ payoff → CTA+price) — swap the treatment, keep the arc; adjust scene count to fit (T5–T7 run ~5 tighter scenes).

> Add new templates as numbered rows (T8, T9 …). Capture the **technique/emotion DNA** and keep the reference
> **unbranded** (see the principle at the top). When a customer loves a fresh build, save it here so it
> becomes a reusable, sellable option. Backlog of distinct directions still worth templating: **Kraft
> Scrapbook / Cinematic Photoreal / Riso Alert** (documented as Presets D/E/F in `style-presets.md`) and a
> **Mission-Control HUD** (dark petrol cockpit, sharp telemetry graphics).
