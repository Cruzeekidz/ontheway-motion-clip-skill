# Production workflow & discipline

The craft is mostly in the process. Engine commands (init/lint/inspect/preview/render,
tts/transcribe) belong to the `hyperframes-cli` / `hyperframes-media` skills — this file is the
ad-specific discipline layered on top.

## 0. Analyze source material → `assets.json`

After intake, have the user drop everything into one folder (default `source_material/`), then build a
catalog you actually consult when placing backgrounds/KVs — don't guess from filenames.

- **Images/dims:** `sips -g pixelWidth -g pixelHeight <img>` (or `ffprobe`). Note what each shows.
- **Video duration + dims:** `ffprobe -v error -show_entries format=duration:stream=width,height -of default=noprint_wrappers=1 <vid>`.
- **Video → time ranges (the important part).** Either cut on scene changes and sample a frame per shot:
  ```bash
  # scene-cut timestamps
  ffprobe -v error -show_frames -of csv -f lavfi "movie=clip.mp4,select=gt(scene\,0.3)" 2>/dev/null \
    | grep -oE 'pkt_pts_time=[0-9.]+'
  # or just sample 1 frame every 2s to eyeball spans
  ffmpeg -v error -i clip.mp4 -vf fps=0.5 _scan/f_%03d.png -y
  ```
  Then describe each span (look at the sampled frames; use Gemini vision if many). Record as
  `{start,end,shot}` ranges so you can later pull a *specific range* as a bg clip or grab a frame as a KV.
- **Write `source_material/assets.json`**, e.g.:
  ```json
  {
    "images": [
      {"file":"cover.webp","type":"image","description":"course cover, navy+gold","useFor":"hero","dims":"1200x1500"}
    ],
    "videos": [
      {"file":"shop.mp4","type":"video","duration":18.4,"dims":"1080x1920",
       "useFor":"background",
       "ranges":[
         {"start":"0:00","end":"0:04","shot":"มือชงกาแฟ close-up, ไอควันลอย"},
         {"start":"0:04","end":"0:09","shot":"แพนหน้าร้าน ลูกค้านั่งเต็ม"},
         {"start":"0:09","end":"0:18","shot":"เทลาเต้อาร์ต close-up"}
       ]}
    ],
    "text": [{"file":"menu.txt","type":"text","description":"เมนู+ราคา","useFor":"copy facts"}]
  }
  ```
- Consult this throughout the build; prefer the user's real media (correct range) over stock.

## 0b. Storyboard mockup (HTML) — sign-off before building

Rough thumbnail board so structure gets approved cheaply, before `index.html`.

- One HTML file, **1 row = 1 scene, 2 columns**: left = a **rough SVG sketch** (plain rects/circles/
  text/lines marking where KV/photo/headline/sticker go — deliberately crude, a thumbnail not a frame);
  right = the **AI explanation** (narration line, what's shown, which `assets.json` asset/range, and WHY
  this scene exists). Plain styling (white bg / black text / default sans-serif). `open` it, iterate, then build.
- Keep the storyboard file in the project (e.g. `storyboard.html`) so revisions are visible.

## 1. Transcribe the voiceover → timing map

The narration is the spine. Get word/line timings, then plan scenes against them.

- **Thai (and most non-English): do NOT use the English default model**, and avoid the
  `--dtw` path (it has failed). Run `whisper-cli` directly with `large-v3`:
  ```bash
  whisper-cli --model ~/.cache/hyperframes/whisper/models/ggml-large-v3.bin \
    --output-srt --output-file <name> --language th --max-len 60 <audio.wav>
  ```
- Measure exact duration and set it as the composition `data-duration` and the `<audio>`'s:
  ```bash
  ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 audio.wav
  ```
- Build a scene plan: for each line, a scene with synced headline(s); reveal at the line's start,
  `leave()` just before the next. Aim to follow the speech closely (~+30% density), not every word.

## 2. Gather real assets

**Do this EARLY and grab generously** — before scripting/voicing. The real assets add authenticity
and often expose ground-truth the page *text* got wrong (e.g. the correct instructor name/spelling,
the brand palette, the real tagline). Even an all-AI-plate art direction should still use the real
**course cover** (hero) and **instructor portrait** (avatar).

**From the sale page** (richest source):
- Extract EVERY image reference and download them all into `resource_images/` (don't cherry-pick one):
  ```bash
  # direct + /images/ paths + next/image + og:image + css url()
  grep -oE '/images/[A-Za-z0-9._%-]+\.(webp|jpg|jpeg|png|gif|svg)' page.html | sort -u
  grep -oE 'https?://[^"'"'"' )]+\.(jpg|jpeg|png|webp|svg)' page.html | sort -u
  ```
  Sale-page images commonly live under a single predictable path like `/images/…` — grab the whole set.
  If the page lazy-loads (few images in the SSR HTML), the cover/instructor/guarantee are still usually
  in the static HTML; for the rest, the course's Google Drive (slides/cover) is the fallback source.
- Resize big ones: `sips -Z 1000 in.jpg --out out.jpg` (or `cwebp` for webp). Keep them in `resource_images/`.
- Pull headline copy and the brand palette from the page too.

**Stock footage (background layer only)** via Pexels:
- API key at `~/.config/pexels/key` (read it; don't hardcode). Search:
  ```bash
  curl -s -G "https://api.pexels.com/videos/search" \
    --data-urlencode "query=dark office night" --data-urlencode "orientation=portrait" \
    --data-urlencode "size=medium" -H "Authorization: $(cat ~/.config/pexels/key)"
  ```
  Pick dark/moody clips **longer than their segment** (so they never freeze), small renditions
  (540×960 is plenty at 10–20% opacity). Preview one frame before committing.
- Pexels footage is free for commercial use, no attribution required.

**Fonts** (Thai): download local `woff2` (e.g. Anakotmai, Sarabun from
`https://cdn.jsdelivr.net/gh/lazywasabi/thai-web-fonts@7/fonts/`) into `fonts/` and `@font-face`
them with `font-display:block`. Don't depend on system or emoji fonts.

## 3. Validate

`lint` (structural) → `validate` (WCAG contrast, headless Chrome) → `inspect` (layout overflow/overlap).

Known **false positives** in these ads (confirm, don't blindly fix):
- **Cross-scene overlap** — scenes are stacked full-frame; `inspect` compares geometry across
  scenes ignoring opacity, so a visible scene "overlaps" hidden sibling scenes. Real overlap is
  within one visible scene only.
- **Contrast on a hidden element** — `validate` samples at fixed times; if it samples a cream
  bubble / accent node while that element is `opacity:0`, it reads element-color-on-dark and flags
  a low ratio. When the element is actually visible the contrast is fine.
- For genuinely intentional layering (typing/reply stack), mark `data-layout-allow-overlap`; for
  transient entrance overflow (slide-in from offscreen), mark the scene column `data-layout-allow-overflow`.

**Recurring REAL overlap to pre-empt — big price/number over a kicker.** A very large price (`฿4,900` at
~100px) with a tight `line-height:1` sits in a glyph box taller than it looks and **overlaps the small
kicker line above it** → `inspect` flags `content_overlap` (kicker inside price). Fix proactively: give the
price row its own `margin` (≈10–12px top/bottom) and `line-height:≥1.05`, or drop the price font a notch.
Seen on multiple offer scenes — bake the spacing in rather than re-rendering to discover it.

## 4. Render, then VERIFY (mandatory)

Never deliver a render you haven't looked at. After rendering, extract frames at each key beat and
view them:
```bash
for t in 5 16 27 37 47 58; do ffmpeg -v error -ss $t -i out.mp4 -frames:v 1 _f/f_$t.png -y; done
```
- Extract **sequentially / in small batches** — many parallel ffmpeg calls can get OOM-killed.
- Check: text readable over the background, images present and framed, chat/diagram beats land,
  the false-positive warnings are actually fine. Then clean up `_f/`.

## 5. Version snapshots

Before iterating on a version the user likes, snapshot it so a re-render can't override it:
```bash
mkdir -p _versions
cp index.html _versions/index_<tag>.html
cp out.mp4 out_<tag>.mp4
```
Keep prior clips/folders intact. When the user says "keep this version", snapshot immediately.

## 6. Background commands

Renders and long curls run in the background; the harness notifies on completion — don't poll with
`sleep` (it's blocked) and don't re-run a search you've delegated. Background tasks may reset CWD —
use absolute paths or the tool's `--dir` flag.

## 7. Third-party adversarial review (MANDATORY before delivering)

After the render passes your own checks, get **fresh outside eyes that never saw the build** to hunt
for faults — the building agent has blind spots and keeps missing "obvious once pointed out" flaws.

1. Build a **detailed contact sheet** — frames every **2–3s** from the rendered mp4 (~20–30 for a 60s ad).
2. **Fan out to every AI vendor callable on the machine**, each a SEPARATE fresh reviewer that is NOT
   the working agent. Detect: `codex` (OpenAI), gemini key `~/.claude/secrets/gemini.env` / `agy` (Google),
   plus a fresh **Claude subagent** via the Agent tool. If none external, still run one Claude subagent.
3. Send **≤5 frames** to each, small–medium CURRENT model per vendor:
   **Claude** `haiku`/`sonnet` · **OpenAI** `gpt-5.6-luna`/`gpt-5.6-terra` (`codex exec -i …`) ·
   **Google** `gemini-3.6-flash` (Gemini REST inline images, or `agy -p`).
4. Prompt = faults-only critic (overlap, face-cover, cropped/off-frame, dead space, tiny/low-contrast
   text, duplicated wording, slow/bare pacing, "AI-made" look) → numbered problems + one-line fixes,
   NO praise. Collect all → fix → re-run the verify gates. Ship only when fresh eyes stop finding real faults.
> (Same procedure detailed in `ontheway-heygen-ad/references/third-party-review.md`.)
