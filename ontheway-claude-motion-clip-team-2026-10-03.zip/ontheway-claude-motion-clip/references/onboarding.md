# First-run onboarding (run ONCE, before the first video)

This skill (packaged & sold) needs two things on a fresh machine:
1. **HyperFrames** render engine — needs **Node.js ≥ 22** + **FFmpeg**.
2. A **Google Gemini API key** — powers the AI **voiceover (TTS)** *and* the AI **images** (KV/plates).

On the **first run**, verify both and **walk the user through anything missing**. Assume the user has
**never set up an API key** — be patient, paste exact URLs/commands, confirm each step worked. Do this
**once**; afterwards only re-check if a command fails with a missing-key / missing-dep error.

## A. Quick check (run these; if all pass → go straight to producing)
```bash
node -v                              # need v22+
ffmpeg -version | head -1            # FFmpeg present?
npx hyperframes doctor               # HyperFrames + deps (downloads whisper model on first use)
# Gemini key present & working? (this also proves the TTS path):
python3 ~/.agents/skills/gemini-tts/scripts/generate_tts.py "ทดสอบเสียง" /tmp/_tts_test.wav
```
The TTS test printing `Successfully …saved` = the key works. If it prints
`GEMINI_API_KEY not found …` → go to **B**. The skill resolves the key in this order: env
`GEMINI_API_KEY` / `GOOGLE_API_KEY` → `~/.claude/secrets/gemini.env` → `~/.config/google-genai/.env`
→ local `.env`.

## B. If the Gemini API key is MISSING — guide the user (most can't do this alone)
Walk them through it, one step at a time, and wait for each to succeed:
1. Open **https://aistudio.google.com/apikey** in a browser; sign in with a Google account.
2. Click **“Create API key”** → **“Create API key in new project.”**
3. **Copy** the displayed key. Current keys commonly start with `AQ…`, but prefixes may change.
   Never require or reject a key based only on its prefix—the verification call in step 5 is authoritative.
   Keep it secret; it is equivalent to a password.
4. Save it where the skill reads it — easiest, works on macOS/Windows/Linux from this CLI:
   ```bash
   mkdir -p ~/.claude/secrets
   printf 'GEMINI_API_KEY=%s\n' "PASTE_YOUR_KEY_HERE" > ~/.claude/secrets/gemini.env
   ```
5. **Verify** with the TTS test in **A**. If it still says “not found,” the pasted key/line is wrong —
   re-open the file and check there are no spaces/quotes around the key.
- **One key, both features:** the same key drives the **voiceover** and the **AI images**. The Gemini API
  **free tier** covers normal use; if a call returns a quota/billing error, the user may need to enable
  billing on their Google Cloud project (link is in the error). 
- **Never print or commit the key.** It lives only in the secrets file.

## C. If HyperFrames / Node / FFmpeg is missing
- **Node ≥ 22:** download from **nodejs.org**, or `brew install node` (macOS) / `winget install OpenJS.NodeJS` (Windows) / `sudo apt install nodejs` (Linux).
- **FFmpeg:** `brew install ffmpeg` (macOS) / `winget install Gyan.FFmpeg` (Windows) / `sudo apt install ffmpeg` (Linux).
- **HyperFrames** itself runs via **`npx hyperframes …`** and auto-installs on first call — no global install
  needed. Confirm the environment with **`npx hyperframes doctor`** (it reports missing deps and downloads
  the Whisper model used for voiceover timing on first use).
- **rembg** (for KV background-removal cutouts) installs on demand:
  `python3.11 -m pip install --user "rembg[cli]" onnxruntime pillow` (only when a cutout step needs it).

## D. OS note
Use the OS-correct file paths and openers (the skills resolve `~`). To *show* the user a file, use
`open` (macOS) / `start ""` (Windows) / `xdg-open` (Linux) — see the house-style rule.
